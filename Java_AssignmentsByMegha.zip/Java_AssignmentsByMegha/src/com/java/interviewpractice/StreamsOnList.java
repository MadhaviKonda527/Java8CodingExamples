package com.java.interviewpractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamsOnList {
	public static void  main(String [] args) {
		List<String> list = Arrays.asList("Apple","Orange","Almond","Grapes","Sapota","Peach");
		list.stream().filter(n-> n.startsWith("A")).forEach(System.out::println);
		System.out.println(list.stream().allMatch(n -> n.length()>5));
		
		
	}

}
