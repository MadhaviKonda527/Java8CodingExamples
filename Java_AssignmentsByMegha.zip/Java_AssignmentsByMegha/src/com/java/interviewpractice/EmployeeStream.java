package com.java.interviewpractice;

import java.util.Arrays;
import java.util.List;

public class EmployeeStream {
	
	List<Employee> empList = Arrays.asList(new Employee(201,"ravi"), new Employee(202,"akshay"));
	
	empList.stream().map(Employee :: getEmp_id).forEach(System.out::println);
	//empList.stream().map(emp -> emp.getEmp_id()).forEach(System.out::println);

}


