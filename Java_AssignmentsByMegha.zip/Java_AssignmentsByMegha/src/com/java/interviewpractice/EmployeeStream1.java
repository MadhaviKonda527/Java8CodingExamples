package com.java.interviewpractice;

import java.util.Arrays;
import java.util.List;

public class EmployeeStream1 {
	
	List<Employee> empList = Arrays.asList(new Employee(201, "Ravi"), new Employee(202,"Akshay"));
	empList.stream().map(Employee :: getEmp_id).forEach(System.out::println);

}
