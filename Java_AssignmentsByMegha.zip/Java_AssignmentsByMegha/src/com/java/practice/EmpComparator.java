package com.java.practice;

import java.util.Comparator;

public class EmpComparator implements Comparator<Employee2>{

	

	@Override
	public int compare(Employee2 o1, Employee2 o2) {
		return Integer.compare(o1.getEmpId(), o2.getEmpId());
	}

}
