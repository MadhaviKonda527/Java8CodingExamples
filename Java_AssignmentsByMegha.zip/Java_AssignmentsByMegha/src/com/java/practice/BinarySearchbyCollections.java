package com.java.practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class BinarySearchbyCollections {

	public static void main(String[] args) {
		String []c = {"A","D","T","H"}; 
        List<String> list = new ArrayList<>();
        list.add("X");
        list.add("G");
        list.add("A");
        list.add("C");
        list.add("K");
        list.add("M");
        Collections.sort(list);// We should sort the list before binarySearch
        System.out.println(list);
        System.out.println(Collections.binarySearch(list, "G"));
        System.out.println(Collections.binarySearch(list, "E"));//It will give u the index where the letter can be inserted(it will take the indexes from -1)
        String min = Collections.min(Arrays.asList(c));
        String max = Collections.max(Arrays.asList(c));
        System.out.println("min:"+min);
        System.out.println("max:"+max);
	}

}
