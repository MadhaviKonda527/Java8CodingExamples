package com.java.practice;

import java.util.ArrayList;
import java.util.Scanner;

public class FindObjByIdInArrayList {

	public static void main(String[] args) {
		ArrayList<MyObject> list = new ArrayList<>();
        list.add(new MyObject(1, "Alice"));
        list.add(new MyObject(2, "Bob"));
        list.add(new MyObject(3, "Charlie"));
        
        Scanner sc = new Scanner(System.in);
        System.out.println("enter id value:");
        int id = sc.nextInt();
        for(MyObject obj : list) {
        	if(obj.getId() == id) {
        		System.out.println(obj);
        	}
        }
        for(int i=0;i<=list.size()-1;i++) {
        	MyObject obj = list.get(i);
        	if(obj.getId() == id) {
        		System.out.println(obj);
        	}
        }
        
        // Find object with ID 2
		/*
		 * MyObject found = findObjectById(list, 2); System.out.println(found);
		 */
    }

    // Method to find object by ID
    public static MyObject findObjectById(ArrayList<MyObject> list, int id) {
        for (MyObject obj : list) {
            if (obj.getId() == id) {
            	 return obj;
            }
        }
        return null; 
      
    }
    


}