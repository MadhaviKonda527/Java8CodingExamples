package com.java.practice;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetImplement {

	public static void main(String[] args) {
       Set<Employee2> set = new TreeSet<Employee2>(new EmpComparator());
    	   set.add(new Employee2(1,"Shristi"));
    	   set.add(new Employee2(2,"Shree"));
    	   set.add(new Employee2(3,"Shruthi"));
    	   set.add(new Employee2(4,"Radha"));
    	   set.add(new Employee2(5,"Ram"));

    	   for(Employee2 emp : set) {
    		   System.out.println(emp.toString());
    	   }
    	   set.forEach(emp -> System.out.println(emp));
    	   set.stream().forEach(System.out::println);
    	   
    	   
	}

}
