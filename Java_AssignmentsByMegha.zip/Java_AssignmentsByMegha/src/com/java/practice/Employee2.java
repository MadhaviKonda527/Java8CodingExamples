package com.java.practice;

public class Employee2 extends EmpComparator{
      private int empId;
      private String name;
      
      public Employee2(int empId, String name) {
    	  this.empId = empId;
    	  this.name = name;
      }
      public int getEmpId() {
    	  return empId;
      }
      public String getName() {
    	  return name;
      }
      
      public String toString() {
    	  return "empId:"+empId+" name:"+name;
      }
}
