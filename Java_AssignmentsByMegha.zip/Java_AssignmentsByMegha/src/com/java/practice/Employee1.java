package com.java.practice;

public class Employee1 implements Comparable<Employee1>{
     private int empId;
     private String name;
     public Employee1(int id, String name) {
    	 this.empId = id;
    	 this.name = name;
     }
	@Override
	public int compareTo(Employee1 o) {
         int i1 = this.empId;
		return Integer.compare(i1, o.empId);
	}
	
	@Override
	public String toString() {
		return "empId:"+empId+"name:"+name;
	}
     
}
