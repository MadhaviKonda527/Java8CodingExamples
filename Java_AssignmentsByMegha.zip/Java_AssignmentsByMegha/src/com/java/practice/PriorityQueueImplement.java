package com.java.practice;

import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueueImplement {

	public static void main(String[] args) {
           Queue<String> que = new PriorityQueue<>();
           que.add("mossambi");
           que.add("Mango");
           que.add("banana");
           que.add("Strwberry");
           que.add("blueberry");
           
           System.out.println(que.peek());
           que.offer("orange");
           System.out.println(que);
           System.out.println(que.poll());
           Object[] array = que.toArray();
           System.out.println(Arrays.toString(array));
           
           
	}

}
