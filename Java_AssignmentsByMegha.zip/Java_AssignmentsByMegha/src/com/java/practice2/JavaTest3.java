package com.java.practice2;

public class JavaTest3 {

	public static void main(String[] args) {
            
	}

}
