package com.java.practice2;

public class JavaSample2 {

	public static void main(String[] args) {
          String s = "1234567890";
          String s1 ="";
          String s2 = "";
          for(int i=0;i<s.length()-1;i++) {
        	  if(i%2==0) {
        		  s1 = s1+s.charAt(i);
        	  }
        	  else {
        		  s2 = s2+s.charAt(i);
        	  }
        	  
          }
          System.out.println(s1+s2);
	}

}
