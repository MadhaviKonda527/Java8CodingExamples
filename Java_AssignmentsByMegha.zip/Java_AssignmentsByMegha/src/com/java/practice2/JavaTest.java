package com.java.practice2;

import java.util.HashMap;
import java.util.Map;

public class JavaTest{

	public static void main(String[] args) {
             HashMap<String, Integer> map = new HashMap<>();
             map.put("Vinay", 30);
             map.put("Ajay", 40);
             map.put("naveen", 50);
             for(String key : map.keySet()){
            	 System.out.println(map.get(key));
             }
             for(Map.Entry<String, Integer> entry : map.entrySet()) {
            	 System.out.println(entry.getKey()+entry.getValue());
             }
             //JavaTest jt = new JavaTest();
             GameInterface up = ()-> {
            	 System.out.println("Going up");
             };
             up.up();
             
             //jt.left();
             
	}

	

	

}
