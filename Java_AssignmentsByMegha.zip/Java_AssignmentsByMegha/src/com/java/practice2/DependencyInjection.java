package com.java.practice2;

public class DependencyInjection {

}
