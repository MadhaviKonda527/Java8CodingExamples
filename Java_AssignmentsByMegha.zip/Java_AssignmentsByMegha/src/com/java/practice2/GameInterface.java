package com.java.practice2;

@FunctionalInterface
public interface GameInterface {
	
         public  void up();
        
}
