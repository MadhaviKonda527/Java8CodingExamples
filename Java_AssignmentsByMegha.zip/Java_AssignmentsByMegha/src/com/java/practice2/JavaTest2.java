package com.java.practice2;

import java.util.Arrays;
import java.util.List;

public class JavaTest2 {

	public static void main(String[] args) {
        List<String> list = Arrays.asList("Ravi", "akhil", "Ram");
        list.stream().filter(a -> !a.equals("Ravi")).forEach(System.out::println);
	}

}
