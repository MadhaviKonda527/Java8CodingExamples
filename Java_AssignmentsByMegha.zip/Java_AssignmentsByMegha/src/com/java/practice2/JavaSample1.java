package com.java.practice2;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class JavaSample1 {

	public static void main(String[] args) {
        String s = "";
        System.out.println("Enter the string:");
        Scanner sc = new Scanner(System.in);
        s = sc.next();
        Map<Character, Integer> count = new HashMap<>();
        for(int i=0;i<=s.length()-1;i++) {
        	if(count.containsKey(s.charAt(i))) {
        		int countC = count.get(s.charAt(i));
        		count.put(s.charAt(i), countC++);
        	}
        	else {
        		count.put(s.charAt(i), 1);
        	}
        }
        count.entrySet().stream().max();
	}

}
