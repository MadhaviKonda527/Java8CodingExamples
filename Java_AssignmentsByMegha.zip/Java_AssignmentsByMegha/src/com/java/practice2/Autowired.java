package com.java.practice2;

public class Autowired {

}
