package com.java.assignments;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import java.util.List;
import java.util.ListIterator;

public class JavaSample3 {

	public static void main(String[] args) {
          List<Integer> list = new ArrayList<>();
          
          for(int i=1; i<=100; i=i+10) {
        	  list.add(i);
          }
          System.out.println(list);
          list.addAll(Arrays.asList(102, 103, 105, 107));
          System.out.println(list);
          list.set(0, 300);
          System.out.println(list);
          if(list.contains(20)) 
        	list.remove(list.indexOf(20));
          System.out.println(list);
          list.remove(0);
          ListIterator itr = list.listIterator();
          while(itr.hasNext())
        	  System.out.print(itr.next()+" ");
         
          System.out.println(list.reversed());
          while(itr.hasPrevious())
        	  System.out.print(itr.previous()+" ");
          System.out.println();
          list.add(0, 400);
          System.out.println(list);
          Collections.sort(list);
          System.out.println(list);
          System.out.println(Collections.max(list));
	}
}
