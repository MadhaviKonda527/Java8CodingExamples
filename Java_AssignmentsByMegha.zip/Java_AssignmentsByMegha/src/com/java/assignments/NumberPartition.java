//NumberPartition.java
package com.java.assignments;

import java.util.ArrayList;
import java.util.List;

public class NumberPartition {

    public static void main(String[] args) {
        int target = 3;
        List<List<Integer>> results = new ArrayList<>();
        findPartitions(target, target, new ArrayList<>(), results);
        
        // Print results
        for (List<Integer> result : results) {
            System.out.println(String.join("+", result.stream().map(String::valueOf).toArray(String[]::new)));
        }
    }

    private static void findPartitions(int target, int max, List<Integer> current, List<List<Integer>> results) {
        if (target == 0) {
            results.add(new ArrayList<>(current));
            return;
        }

        for (int i = 1; i <= max; i++) {
            if (i <= target) {
                current.add(i);
                findPartitions(target - i, i, current, results);
                current.remove(current.size() - 1);
            }
        }
    }
}



/*import java.util.ArrayList;
import java.util.List;

public class NumberPartition {

    public static void main(String[] args) {
        int target = 3;  // Define the target sum
        List<List<Integer>> results = new ArrayList<>();  // List to hold all possible partitions
        findPartitions(target, target, new ArrayList<>(), results);  // Start the partitioning process
        
        // Print results
        for (List<Integer> result : results) {
            System.out.println(String.join("+", result.stream().map(String::valueOf).toArray(String[]::new)));
        }
    }

    private static void findPartitions(int target, int max, List<Integer> current, List<List<Integer>> results) {
        if (target == 0) {  // Base case: if the target is zero, the current partition is valid
            results.add(new ArrayList<>(current));  // Add a copy of the current partition to the results list
            return;  // Exit the current recursive call
        }

        for (int i = 1; i <= max; i++) {  // Loop through possible numbers to include in the partition
            if (i <= target) {  // Only consider the number if it does not exceed the target
                current.add(i);  // Add the number to the current partition
                findPartitions(target - i, i, current, results);  // Recursively find partitions with the reduced target
                current.remove(current.size() - 1);  // Backtrack: remove the last added number to try the next possibility
            }
        }
    }
}*/

