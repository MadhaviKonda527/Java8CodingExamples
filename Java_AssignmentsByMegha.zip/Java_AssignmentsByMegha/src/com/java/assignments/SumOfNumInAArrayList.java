
//SumOfNumInAArrayList.java
package com.java.assignments;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SumOfNumInAArrayList {
	
	public static void main(String args[]) {
		
		//List<Integer> list = new ArrayList<>();
		List<Integer> list1 = Arrays.asList(24,25,78,689);
		int sum = 0, sum1 = 103, current, previous =0;
		for(int i=0;i<=list1.size()-1;i++) {
		sum = sum + list1.get(i);
		current = list1.get(i);
		if(i>0)
		   previous = list1.get(i-1);
		if(previous + current == sum1) {
			//System.out.println(previous+"\t"+current);
			System.out.println(list1);
		}else
			list1.remove(previous);
		}
		System.out.println(sum);
		
		
	}

}
