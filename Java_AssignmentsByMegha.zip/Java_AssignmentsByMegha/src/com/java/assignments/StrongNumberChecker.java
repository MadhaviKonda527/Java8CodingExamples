
//StrongNumberChecker.java
package com.java.assignments;

import java.math.BigInteger;

public class StrongNumberChecker {

    public static void main(String[] args) {
        int number = 145;
        System.out.println("Is the number " + number + " a Strong number? " + isStrongNumber(number));
    }

    private static boolean isStrongNumber(int number) {
        // Store the original number for comparison
        int originalNumber = number;
        int sumOfFactorials = 0;

        // Process each digit
        while (number > 0) {
            int digit = number % 10;  // Extract the last digit
            sumOfFactorials += factorial(digit);  // Add the factorial of the digit to the sum
            number /= 10;  // Remove the last digit
        }

        // Compare the sum of factorials to the original number
        return sumOfFactorials == originalNumber;
    }

    private static int factorial(int n) {
        // Calculate factorial using BigInteger to handle large values
        return (n == 0 || n == 1) ? 1 : BigInteger.valueOf(n).multiply(BigInteger.valueOf(factorial(n - 1))).intValue();
    }
}
