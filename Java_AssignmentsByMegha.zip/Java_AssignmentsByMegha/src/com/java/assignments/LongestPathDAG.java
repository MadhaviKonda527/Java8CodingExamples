
//LongestPathDAG.java
package com.java.assignments;

import java.util.*;

public class LongestPathDAG {
    static class Graph {
        int V;
        List<List<Integer>> adjList;

        Graph(int v) {
            V = v;
            adjList = new ArrayList<>(v);
            for (int i = 0; i < v; i++) {
                adjList.add(new ArrayList<>());
            }
        }

        void addEdge(int u, int v) {
            adjList.get(u).add(v);
        }

        // Method to perform topological sort
        private void topologicalSortUtil(int v, boolean[] visited, Stack<Integer> stack) {
            visited[v] = true;
            for (int neighbor : adjList.get(v)) {
                if (!visited[neighbor]) {
                    topologicalSortUtil(neighbor, visited, stack);
                }
            }
            stack.push(v);
        }

        // Method to find the longest path in the DAG
        public void longestPath(int s, int d) {
            Stack<Integer> stack = new Stack<>();
            boolean[] visited = new boolean[V];
            
            // Perform topological sort
            for (int i = 0; i < V; i++) {
                if (!visited[i]) {
                    topologicalSortUtil(i, visited, stack);
                }
            }

            // Initialize distances to all vertices as negative infinity
            int[] dist = new int[V];
            Arrays.fill(dist, Integer.MIN_VALUE);
            dist[s] = 0;

            // Process vertices in topological order
            while (!stack.isEmpty()) {
                int u = stack.pop();

                if (dist[u] != Integer.MIN_VALUE) {
                    for (int v : adjList.get(u)) {
                        if (dist[u] + 1 > dist[v]) {
                            dist[v] = dist[u] + 1;
                        }
                    }
                }
            }

            // Print the longest path length
            if (dist[d] != Integer.MIN_VALUE) {
                System.out.println("The longest path length from " + s + " to " + d + " is " + dist[d]);
            } else {
                System.out.println("No path exists from " + s + " to " + d);
            }
        }
    }

    public static void main(String[] args) {
        // Create a graph with 6 vertices
        Graph g = new Graph(6);
        g.addEdge(0, 1);
        g.addEdge(0, 2);
        g.addEdge(1, 3);
        g.addEdge(2, 3);
        g.addEdge(2, 4);
        g.addEdge(4, 5);

        int source = 0;
        int destination = 5;
        g.longestPath(source, destination);
    }
}

