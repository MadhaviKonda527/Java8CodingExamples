
//PanagramChecker.java
package com.java.assignments;

import java.util.HashSet;
import java.util.Set;

public class PanagramChecker {

    public static void main(String[] args) {
        String input = "The quick brown fox jumps over the lazy dog.";
        System.out.println("Is the string a pangram? " + isPangram(input));
    }

    private static boolean isPangram(String str) {
        // Convert the string to lowercase to handle case insensitivity
        str = str.toLowerCase();
        
        // Create a set to track the unique letters
        Set<Character> letters = new HashSet<>();
        
        // Iterate over each character in the string
        for (char ch : str.toCharArray()) {
            // Check if the character is a letter
            if (Character.isLetter(ch)) {
                letters.add(ch);
            }
        }
        
        // A string is a pangram if it contains all 26 letters of the alphabet
        return letters.size() == 26;
    }
}

