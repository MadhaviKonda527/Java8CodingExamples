

//JavaSample1.java
package com.java.assignments;

import java.util.HashMap;
import java.util.Map;

public class JavaSample1 {

	public static void main(String[] args) {
	
		        // Simulated data: Admin -> 10 users, Customer -> 200000 users
		        Map<String, Integer> userRoles = new HashMap<>();
		        userRoles.put("Admin", 10);
		        userRoles.put("Customer", 200000);

		        // Counting users for each role
		        long adminCount = userRoles.entrySet().stream()
		                .filter(entry -> entry.getKey().equals("Admin"))
		                .mapToLong(Map.Entry::getValue)
		                .sum();

		        long customerCount = userRoles.entrySet().stream()
		                .filter(entry -> entry.getKey().equals("Customer"))
		                .mapToLong(Map.Entry::getValue)
		                .sum();

		        // Output the results
		        //System.out.println("Number of Admin users: " + adminCount);
		        //System.out.println("Number of Customer users: " + customerCount);
		        
		        userRoles.entrySet().stream().filter(entry -> entry.getKey().equals("Admin")).forEach(System.out::println);
		    }
		

	}


