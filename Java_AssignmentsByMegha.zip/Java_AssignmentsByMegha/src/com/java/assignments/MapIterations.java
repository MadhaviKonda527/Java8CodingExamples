//MapIterations.java
package com.java.assignments;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class MapIterations {

	public static void main(String[] args) {
         Map<Integer, String> map = new HashMap<>();
         
        	 map.put(1, "car");
        	 map.put(2, "bike");
        	 map.put(3, "bus");
        	 map.put(4, "cycle");
        	 map.put(5, "truck");
        	 
        	 System.out.println(map);
        	 
        	 for(Map.Entry<Integer, String> entry : map.entrySet()){
        		 System.out.print("Key:"+ entry.getKey()+"Value:"+entry.getValue()+" ");
        		 
        	 }
        	 System.out.println();
        	 for(Integer key : map.keySet()) {
        		 System.out.print("Key:"+ key+"Value"+map.get(key)+" ");
        	 }
        	 System.out.println();
        	 for(String val : map.values()) {
        		 System.out.println(val);
        	 }
        	 System.out.println();
        	 map.forEach((key, value)-> System.out.print(key +" "+value+" "));
        	 System.out.println();
        	 map.entrySet().forEach(entry -> System.out.print(entry.getKey()+" "+entry.getValue()+" "));
        	 System.out.println();
        	 map.forEach((key, value) -> System.out.print(key +" "+ value+" "));
        	 System.out.println();
        	 map.entrySet().stream().filter(entry -> entry.getValue().endsWith("ck")).forEach(System.out::println);
        	 map.entrySet().stream().collect(Collectors.sort());
	}

}
