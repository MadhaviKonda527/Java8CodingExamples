
//RandomExample.java
package com.java.assignments;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class RandomExample {

	public static void main(String[] args) {
           Random ran = new Random();
           List<Integer> list = new LinkedList<>();
           for(int i=0;i<10;i++) {
           int r = ran.nextInt();
           list.add(r);
           }
           System.out.println(list);
           
           int r = ran.nextInt(100);
           list.add(r);
           System.out.print(list);
	}

}
