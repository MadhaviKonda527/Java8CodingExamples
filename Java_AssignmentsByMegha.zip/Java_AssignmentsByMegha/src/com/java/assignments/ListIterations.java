
//List Iterations
package com.java.assignments;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.stream.Collectors;

public class ListIterations {

	public static void main(String[] args) {
         List<Integer> list = new ArrayList<>();
         for(int i=50;i<500;i=i+50) {
        	 list.add(i);
        	 
         }
         System.out.println(list.stream().collect(Collectors.toList()));
         list.forEach(i -> System.out.print(i+" "));
         System.out.println();
         list.stream().filter(i -> i%2==0).forEach(System.out::println);
         list.forEach(System.out::print);
         ListIterator<Integer> itr = list.listIterator();
         while(itr.hasNext()) {
        	 System.out.println(itr.next());
        	 
         }
         	}

}
