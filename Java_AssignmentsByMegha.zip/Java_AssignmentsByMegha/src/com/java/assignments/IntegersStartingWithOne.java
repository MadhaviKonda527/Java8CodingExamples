

//IntegersStartingWithOne.java
package com.java.assignments;

import java.util.Arrays;
import java.util.List;

public class IntegersStartingWithOne {
	public static void main(String[] args) {
	      List<Integer> a = Arrays.asList(1738,283,18633,374,9835,1936,2477,1878,19,10);
	      a.stream().filter(n->n.toString().startsWith("1")).forEach(System.out::println);
		}
}
