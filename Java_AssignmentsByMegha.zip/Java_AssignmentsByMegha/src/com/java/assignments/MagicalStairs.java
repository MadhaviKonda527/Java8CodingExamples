
//MagicalStairs.java
package com.java.assignments;

import java.util.ArrayList;
import java.util.List;

public class MagicalStairs {
    
    public static void main(String[] args) {
        int n = 5; // Change this to the desired step number
        List<List<Integer>> results = new ArrayList<>();
        findAllWays(n, 0, 0, new ArrayList<>(), results);
        
        // Print all the possible ways
        for (List<Integer> path : results) {
            System.out.println(path);
        }
    }
    
    // Recursive method to find all possible ways to reach the nth step
    private static void findAllWays(int target, int current, int lastJump, List<Integer> currentPath, List<List<Integer>> results) {
        // Base case: if current step equals target, add path to results
        if (current == target) {
            results.add(new ArrayList<>(currentPath));
            return;
        }
        
        // If current step exceeds target, return
        if (current > target) {
            return;
        }
        
        // Try jumping `lastJump`, `lastJump + 1`, or `lastJump + 2` steps
        for (int jump = lastJump; jump <= lastJump + 2; jump++) {
            if (jump > 0) { // Skip non-positive jumps
                currentPath.add(jump);
                findAllWays(target, current + jump, jump, currentPath, results);
                currentPath.remove(currentPath.size() - 1); // Backtrack
            }
        }
    }
}

