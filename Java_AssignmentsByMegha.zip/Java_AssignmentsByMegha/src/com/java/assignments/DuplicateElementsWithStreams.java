

//DuplicateElementsWithStreams.java
package com.java.assignments;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class DuplicateElementsWithStreams {
	public static void main(String[] args) {
	      List<Integer> a = Arrays.asList(167,2,3,4,5,8,6,7,8,9,1,5,2);
	      Optional<Integer> first = a.stream().findFirst();
	      long count = a.stream().count();
	      List<Integer> collect = a.stream().distinct().collect(Collectors.toList());
	      System.out.println(collect);
	      System.out.println(first);
	      System.out.println(count);
	      a.stream().distinct().forEach(System.out::println);
	      boolean b = a.stream().allMatch(n -> n%2==0);
	      boolean b1 = a.stream().anyMatch(n -> n%2==0);
	      List<Integer> list =a.stream().collect(Collectors.collectingAndThen(Collectors.toList(), Collections :: unmodifiableList));
		}
}
