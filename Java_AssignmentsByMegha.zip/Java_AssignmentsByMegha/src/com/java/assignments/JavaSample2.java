package com.java.assignments;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class JavaSample2 {

	public static void main(String[] args) {
           Map<String, Integer> map = new HashMap<>();
           map.put("cars", 40);
           map.put("Bikes", 60);
           map.put("autos", 100);
           
         map.keySet().stream().forEach(k -> System.out.println("no.of"+k+"-"+map.get(k)));
	}

}
