package com.coderpad;

public class ReverseStringWithPreservingOrder {

    public static void main(String[] args) {
        // Example inputs
        String input1 = "abcd";
        String input2 = "I am Java Developer";
        
        // Process and print the outputs
        System.out.println("Reversed string with preserving order for input 1: " + reversePreservingOrder(input1));
        System.out.println("Reversed string with preserving order for input 2: " + reversePreservingOrder(input2));
    }
    
    public static String reversePreservingOrder(String input) {
        // Split the input string into words based on spaces
        String[] words = input.split(" ");
        StringBuilder reversedString = new StringBuilder();
        
        // Iterate through each word, reverse it, and append to the result
        for (String word : words) {
            String reversedWord = new StringBuilder(word).reverse().toString();
            reversedString.append(reversedWord).append(" ");
        }
        
        // Remove the trailing space and return the result
        return reversedString.toString().trim();
    }
}
