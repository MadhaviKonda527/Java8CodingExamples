package com.coderpad;

import java.util.HashSet;
import java.util.Set;

public class RemoveCommonCharacters {

    // Method to find common characters in all strings
    private static Set<Character> findCommonCharacters(String[] strings) {
        Set<Character> commonChars = new HashSet<>();
        if (strings.length == 0) return commonChars;
        
        // Initialize commonChars with characters from the first string
        for (char ch : strings[0].toCharArray()) {
            commonChars.add(ch);
        }
        
        // Intersect with characters from the rest of the strings
        for (int i = 1; i < strings.length; i++) {
            Set<Character> currentSet = new HashSet<>();
            for (char ch : strings[i].toCharArray()) {
                if (commonChars.contains(ch)) {
                    currentSet.add(ch);
                }
            }
            commonChars = currentSet;
        }
        
        return commonChars;
    }

    // Method to remove common characters from a given string
    private static String removeCommonCharacters(String str, Set<Character> commonChars) {
        StringBuilder result = new StringBuilder();
        for (char ch : str.toCharArray()) {
            if (!commonChars.contains(ch)) {
                result.append(ch);
            }
        }
        return result.toString();
    }

    public static void main(String[] args) {
        String[] strings = {"hello", "world", "java"};

        // Find common characters
        Set<Character> commonChars = findCommonCharacters(strings);

        // Print common characters for reference
        System.out.println("Common characters: " + commonChars);

        // Remove common characters from each string and print the result
        for (String str : strings) {
            String result = removeCommonCharacters(str, commonChars);
            System.out.println("String after removing common characters: " + result);
        }
    }
}

