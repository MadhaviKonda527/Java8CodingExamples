package com.coderpad;

public class BSTInOrderTraversal {
	
	void insert(int node) {
		if(node>root) {
			
		}
	}

	public static void main(String[] args) {
		BSTInOrderTraversal tree = new BSTInOrderTraversal();
		tree.insert()
	}

}
