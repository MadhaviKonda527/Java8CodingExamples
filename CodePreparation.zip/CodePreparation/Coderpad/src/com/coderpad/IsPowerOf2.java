package com.coderpad;

public class IsPowerOf2 {

	public static void main(String[] args) {
		int n = 16;
        if(n<=0) {
     	   System.out.println(false);
     	   
        }
        
        while(n>1) {
     	   if(n%2!=0) {
     		   System.out.println(false);
     		   break;
     	   }
     	   n = n/2;
     	   if(n==2) {
     		   System.out.println(true);
     		   break;
     		  
     	  }
        }
        
        
	}

}
