package com.coderpad;

import java.util.HashSet;
import java.util.Set;

public class PangramDetector {

    public static void main(String[] args) {
        // Example string to check
        String sentence = "The quick brown fox jumps over the lazy dog";
        
        // Convert the sentence to lowercase and remove non-alphabetic characters
        String cleanedSentence = sentence.toLowerCase().replaceAll("[^a-z]", "");
        
        // Call the function to check if the sentence is a pangram and print missing letters if needed
        checkPangram(cleanedSentence);
    }
    
    public static void checkPangram(String sentence) {
        Set<Character> letterSet = new HashSet<>();
        
        // Add all unique letters to the set
        for (char c : sentence.toCharArray()) {
            if (Character.isLetter(c)) {
                letterSet.add(c);
            }
        }
        
        // Check if all 26 letters are present
        if (letterSet.size() == 26) {
            System.out.println("The given string is a pangram.");
        } else {
            System.out.println("The given string is not a pangram.");
            // Calculate missing letters
            Set<Character> allLetters = new HashSet<>();
            for (char c = 'a'; c <= 'z'; c++) {
                allLetters.add(c);
            }
            allLetters.removeAll(letterSet);
            
            // Print missing letters
            System.out.print("Missing letters: ");
            for (char c : allLetters) {
                System.out.print(c + " ");
            }
            System.out.println();
        }
    }
}

