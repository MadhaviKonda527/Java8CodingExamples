package com.coderpad;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MaximumAverageGrade {
    public static void main(String[] args) {
        // Input 2D array
        String[][] input = {
            {"Rohit", "85"},
            {"Rahul", "80"},
            {"Amit", "85"},
            {"Rohit", "90"}
        };
        
        // HashMap to store grades for each student
        Map<String, ArrayList<Integer>> studentGrades = new HashMap<>();
        
        // Process the input array
        for (String[] entry : input) {
            String student = entry[0];
            int grade = Integer.parseInt(entry[1]);
            
            // Initialize if student is not present in the map
            studentGrades.putIfAbsent(student, new ArrayList<>());
            studentGrades.get(student).add(grade);
        }
        
        // Variable to store the maximum average
        int maxAverage = Integer.MIN_VALUE;
        
        // Calculate the average for each student and find the maximum average
        for (Map.Entry<String, ArrayList<Integer>> entry : studentGrades.entrySet()) {
            ArrayList<Integer> grades = entry.getValue();
            
            // Calculate the sum of grades
            int sum = 0;
            for (int grade : grades) {
                sum += grade;
            }
            
            // Calculate the average and round down
            int average = sum / grades.size();
            
            // Update the maximum average
            if (average > maxAverage) {
                maxAverage = average;
            }
        }
        
        // Print the result
        System.out.println(maxAverage);
    }
}