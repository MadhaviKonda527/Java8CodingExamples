package com.coderpad;

import java.util.Map;
import java.util.Set;

public class User {
	
	private String requestBook;
	private String userName;
	
	public User(String userName, String requestBook) {
		this.userName = userName;
		this.requestBook = requestBook;
	}
	
	private Map<String, String> waitinglist;
	waitinglist.put(userName, requestBook);
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	Map<String, Set<String>> userBooks;
	Set<String> Books;
      
	public String getRequestBook() {
		return requestBook;
	}

	public void setRequestBook(String requestBook) {
		this.requestBook = requestBook;
	}

	public void borrowBook(Book book){
		book.borrowCopy(user);
	}
	
	public void returnBook(Book book) {
		book.returnCopy(User user);
	}
      
}
