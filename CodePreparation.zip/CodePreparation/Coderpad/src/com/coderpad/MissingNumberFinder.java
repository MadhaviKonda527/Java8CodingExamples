package com.coderpad;

public class MissingNumberFinder {

    // Method to find the missing number
    public static int findMissingNumber(int[] arr) {
        int n = arr.length + 1;  // since one number is missing, length of array is one less than the actual number of elements
        int expectedSum = n * (n + 1) / 2;  // Sum of first n natural numbers
        int actualSum = 0;

        // Calculate the sum of elements in the array
        for (int num : arr) {
            actualSum += num;
        }

        // The missing number is the difference between expected sum and actual sum
        return expectedSum - actualSum;
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 4, 5, 6};  // Example array where 3 is missing

        int missingNumber = findMissingNumber(arr);
        System.out.println("The missing number is: " + missingNumber);
    }
}
