package com.coderpad;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MaxSubStringInAGivenString {

	public static void main(String args[]) {
		String s = "banana";
		Set<String> set = new HashSet<>();
		int max = s.length();
		for(int i=0;i<max;i++) {
			if(i!=max) {
				for(int j=i+1;j<max;j++) {
					set.add(s.substring(i,j+1));
				}
			}
			else {
					set.add(s.substring(i));
				
			}
		}
		List<String> list = set.stream().sorted().toList();
		System.out.println(list.getLast());
	}
}
