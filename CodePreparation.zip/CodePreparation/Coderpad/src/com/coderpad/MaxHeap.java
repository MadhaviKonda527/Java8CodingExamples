package com.coderpad;


	public class MaxHeap {
	    private int[] heap;
	    private int size;
	    private int capacity;

	    public MaxHeap(int capacity) {
	        this.capacity = capacity;
	        this.size = 0;
	        heap = new int[capacity];
	    }

	    // Return the index of the parent of the node at index i
	    private int parent(int i) { return (i - 1) / 2; }

	    // Return the index of the left child of the node at index i
	    private int leftChild(int i) { return 2 * i + 1; }

	    // Return the index of the right child of the node at index i
	    private int rightChild(int i) { return 2 * i + 2; }

	    // Swap elements at indices i and j
	    private void swap(int i, int j) {
	        int temp = heap[i];
	        heap[i] = heap[j];
	        heap[j] = temp;
	    }

	    // Heapify the subtree rooted at index i
	    private void heapify(int i) {
	        int largest = i;
	        int left = leftChild(i);
	        int right = rightChild(i);

	        if (left < size && heap[left] > heap[largest]) {
	            largest = left;
	        }

	        if (right < size && heap[right] > heap[largest]) {
	            largest = right;
	        }

	        if (largest != i) {
	            swap(i, largest);
	            heapify(largest);
	        }
	    }

	    // Insert a new element into the heap
	    public void insert(int value) {
	        if (size == capacity) {
	            throw new IllegalStateException("Heap is full");
	        }

	        heap[size] = value;
	        int current = size;
	        size++;

	        // Fix the max heap property if it's violated
	        while (current > 0 && heap[current] > heap[parent(current)]) {
	            swap(current, parent(current));
	            current = parent(current);
	        }
	    }

	    // Extract the maximum element from the heap
	    public int extractMax() {
	        if (size <= 0) {
	            throw new IllegalStateException("Heap is empty");
	        }
	        if (size == 1) {
	            size--;
	            return heap[0];
	        }

	        int root = heap[0];
	        heap[0] = heap[size - 1];
	        size--;
	        heapify(0);

	        return root;
	    }

	    // Peek at the maximum element of the heap
	    public int peek() {
	        if (size <= 0) {
	            throw new IllegalStateException("Heap is empty");
	        }
	        return heap[0];
	    }

	    // Print the heap elements
	    public void printHeap() {
	        for (int i = 0; i < size; i++) {
	            System.out.print(heap[i] + " ");
	        }
	        System.out.println();
	    }

	    // Main method for testing
	    public static void main(String[] args) {
	        MaxHeap maxHeap = new MaxHeap(10);

	        maxHeap.insert(3);
	        maxHeap.insert(5);
	        maxHeap.insert(9);
	        maxHeap.insert(1);
	        maxHeap.insert(4);

	        System.out.println("Heap elements:");
	        maxHeap.printHeap();

	        System.out.println("Max element extracted: " + maxHeap.extractMax());
	        System.out.println("Heap elements after extraction:");
	        maxHeap.printHeap();
	    
	}

}
