package com.coderpad;

import java.util.Arrays;
import java.util.Comparator;

public class SentenceFormatting {

	public static void main(String[] args) {
		String s = "The lines are printed in reverse order";
		
		String[] words = s.split(" ");
		Arrays.sort(words, Comparator.comparingInt(String :: length).thenComparing(String :: compareToIgnoreCase));
	    words[0] = words[0].substring(0,1).toUpperCase()+words[0].substring(1).toLowerCase();
	    for(int i=1;i<words.length-1;i++) {
	    	words[i] = words[i].toLowerCase();
	    }
	    String sr = String.join(" ", words);
	    System.out.println(sr);
	}

}
