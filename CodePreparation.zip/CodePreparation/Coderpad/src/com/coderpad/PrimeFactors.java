package com.coderpad;

import java.util.ArrayList;
import java.util.List;

public class PrimeFactors {

	public static void main(String[] args) {
        int n =135;
        List<Integer> nfact = new ArrayList<>();
        if(n<1)
        	System.out.println(nfact);
        while(n%2==0) {
        	nfact.add(2);
        	n=n/2;
        }
        System.out.println(Math.sqrt(n));
        for(int i=3;i<=Math.sqrt(n);i=i+2) {
        	while(n%i==0) {
        		nfact.add(i);
        		n=n/i;
        	}
        }
        if(n>2)
        	nfact.add(n);
        System.out.println(nfact);
       
	}

}
