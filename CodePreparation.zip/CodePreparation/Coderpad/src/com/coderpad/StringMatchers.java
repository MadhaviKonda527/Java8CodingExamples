package com.coderpad;

import java.util.ArrayList;
import java.util.List;

public class StringMatchers {

	public static void main(String[] args) {
        String[] input = {"ant", "aplphabet", "cat", "it", "giant", "titanic", "tan", "fant", "brocat", "fan", "bet", "rit"};
	   List<String> matches = new ArrayList<>();  
        for(int i=0;i<input.length;i++) {
	    	    String match= input[i];
	    	  for(int j=0;j<input.length;j++) {
	    		  if(match.length()<input[j].length()&&input[j].contains(match)) {
	    			  matches.add(input[j]);
	    		  }
	    	  }
	    	  if(!matches.isEmpty())
	    	  System.out.println(input[i]+"-"+matches);
	    	  matches.clear();
	      }
        
	}

}
