package com.coderpad;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

class StringComparatorTESARDLK {

	  static class StringComparator implements Comparator<String>{
	        @Override
	        public int compare(String s1, String s2){
	          String o = "TESARDLK";int pos1=0,pos2=0,result=0;
	          char[] c = o.toCharArray();
	          for(int i=0;i<c.length-1;i++){
	            char ch1 = s1.charAt(0);
	            char ch2 = s2.charAt(0);
	            if(ch1==c[i]){
	              pos1 = i;
	            }
	            if(ch2==c[i]){
	              pos2 = i;
	            }
	          }
	          if(pos1==pos2) 
	          result= 0;
	          if(pos1<pos2) 
	          result= -1;
	          if(pos1>pos2) 
	          result= 1;
			return result;
			
	          
	          }
	  }

	  public static void main(String[] args){
	    List<String> s = Arrays.asList("Ajay","Raja","Keshav","List","Set","Elephant","Drone");
	    
	    Set<String> set = new TreeSet<>(new StringComparator());
	          set.addAll(s);
	           System.out.println(set);
	  }
	 

	}
