package com.coderpad;

public class IsPowerOf10 {

	public static void main(String[] args) {
           int n = 90;
           if(n<=0) {
        	   System.out.println(false);
        	   
           }
           
           while(n>1) {
        	   if(n%10!=0) {
        		   System.out.println(false);
        	   }
        	   
        	   if(n==10)
        		   System.out.println(true);
        	   n = n/10;
           }
           
           
	}

}
