package com.coderpad;

import java.util.HashSet;
import java.util.Set;

public class StringArrayProcessor {

    public static void main(String[] args) {
        // Input string array
        String[] inputArray = {"apple", "sample", "search", "cat"};
        
        // Task A: Print all strings that start with 'S'
        System.out.println("Strings that start with 'S':");
        printStringsStartingWithS(inputArray);
        
        // Task B: Check if each string has all unique characters
        System.out.println("Strings with all unique characters:");
        printUniqueCharacterStrings(inputArray);
    }
    
    // Task A: Print all strings that start with 'S'
    public static void printStringsStartingWithS(String[] array) {
        for (String str : array) {
            if (str.startsWith("S") || str.startsWith("s")) { // Handle both uppercase and lowercase 'S'
                System.out.println(str);
            }
        }
    }
    
    // Task B: Check if each string has all unique characters
    public static void printUniqueCharacterStrings(String[] array) {
        for (String str : array) {
            if (hasAllUniqueCharacters(str)) {
                System.out.println(str);
            }
        }
    }
    
    // Helper method to check if a string has all unique characters
    public static boolean hasAllUniqueCharacters(String str) {
        Set<Character> charSet = new HashSet<>();
        for (char c : str.toCharArray()) {
            if (charSet.contains(c)) {
                return false; // Duplicate character found
            }
            charSet.add(c);
        }
        return true; // All characters are unique
    }
}
