package com.coderpad;

public class LinearProbing {

	public static void main(String[] args) {
        int[] arr = {20,35,76,81,90};
        int n = arr.length;
        int[] hashtable = new int[n];
        
        for (int i = 0; i < hashtable.length; i++)
			hashtable[i] = -1;
        
        for(int i=0;i<n;i++) {
        	
        	int hashvalue=arr[i]%n;
        	//System.out.println(hashvalue=arr[i]%n);
        	if(hashtable[hashvalue]==-1) {
        		hashtable[hashvalue] = arr[i];
        	}
        	else {
        		for(int j=hashvalue+1;j<hashtable.length;j++) {
        			if(hashtable[j]==-1) {
                		hashtable[j] = arr[i];
                		break;
                	}
        			else {
        				continue;
        			}
        		}
        	}
        }
        
        printArray(hashtable);
	}
	private static void printArray(int[] hashTable)
	{
		for (int i = 0; i < hashTable.length; i++)
			System.out.println(hashTable[i]);
		// TODO Auto-generated method stub
		
	}

}
