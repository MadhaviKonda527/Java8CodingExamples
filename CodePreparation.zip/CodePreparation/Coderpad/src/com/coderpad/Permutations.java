package com.coderpad;

public class Permutations {

    // Method to print all permutations of a given string
    public static void printPermutations(String str) {
        // Convert the string to a character array
        char[] chars = str.toCharArray();
        // Call the recursive method to generate permutations
        permute(chars, 0);
    }

    // Recursive method to generate permutations
    private static void permute(char[] chars, int index) {
        // If index reaches the end of the array, print the permutation
        if (index == chars.length - 1) {
            System.out.println(new String(chars));
            return;
        }

        // Swap each character with the current index and permute the rest
        for (int i = index; i < chars.length; i++) {
            swap(chars, index, i);
            permute(chars, index + 1);
            swap(chars, index, i); // backtrack to restore the original configuration
        }
    }

    // Method to swap two characters in the array
    private static void swap(char[] chars, int i, int j) {
        char temp = chars[i];
        chars[i] = chars[j];
        chars[j] = temp;
    }

    // Main method to test the permutation function
    public static void main(String[] args) {
        String str = "ABC"; // Change this to any string you want to test
        printPermutations(str);
    }
}
