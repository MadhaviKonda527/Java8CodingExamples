package com.coderpad;

public class IsPowerOf5 {

	public static void main(String[] args) {
		int n = 3125;
		String s = "623";
		if((s.substring(s.length()-2)).equals("25")) {
			//System.out.println(true);
		}
		//System.out.println(false);
		double log = Math.log(625);
		System.out.println(Math.log10(625));
		if((int)log==4) {
			System.out.println(true);
		}
		else System.out.println(false);
        /*if(n<=0) {
     	   System.out.println(false);
     	   
        }
        
        while(n>1) {
     	   if(n%5!=0) {
     		   System.out.println(false);
     		   break;
     	   }
     	   n = n/5;
     	   if(n==5) {
     		   //System.out.println(true);
     		   break;
     		  
     	  }
        }*/
	}

}
