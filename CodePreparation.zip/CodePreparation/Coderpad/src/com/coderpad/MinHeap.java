package com.coderpad;

public class MinHeap {
	private int capacity;
	private int size;
	private int heap[];
	
	public MinHeap(int capacity) {
		this.capacity = capacity;
		this.size = 0;
		heap = new int[capacity];
		
	}
	
	public int leftChild(int i) { return 2 * i + 1; }
	public int rightChild(int i) { return 2 * i + 2; }
	public int parent(int i) { return i; }
	
	public void swap(int i, int small) {
		int temp = heap[i];
		heap[i] = heap[small];
		heap[small] = temp;
	}
	
	public void heapify(int i) {
		int left = leftChild(i) ;
        int right = rightChild(i) ;
        int smallest = parent(i);
        
        if(left<size&&heap[left]<heap[smallest]) {
        	smallest = left;
        }
        if(left<size&&heap[right]<heap[smallest]) {
        	smallest = right;
        }
        if(smallest!=i) {
        	swap(i,smallest);
        	heapify(smallest);
        }
	}
	
	public void insert(int value) {
		if(size == capacity) {
			throw new IllegalStateException("Heap is full");
		}
		heap[size] = value;
		int current = size;
		size++;
		
		while(current>0 && heap[current]<heap[parent(current)]) {
			swap(current,parent(current));
			current = parent(current);
		}
	}
	
	public int extractMin() {
		if(size<=0) {
			throw new IllegalStateException("Stack is empty");
		}
		if(size==1) {
			size--;
			return heap[0];
		}
		
		int root = heap[0];
		heap[0] = heap[size-1];
		size--;
		heapify(0);
		return root;
	}
	
	public int peek() {
		if(size<=0) {
			throw new IllegalStateException("Stack is empty");
		}
		
		return heap[0];
	}
	
	public void printHeap() {
		for(int i=0;i<heap.length;i++) {
			System.out.print(heap[i]+" ");
		}
		System.out.println();
	}

	public static void main(String[] args) {
		MinHeap minHeap = new MinHeap(10);

		minHeap.insert(3);
		minHeap.insert(5);
		minHeap.insert(9);
        minHeap.insert(1);
        minHeap.insert(4);

        System.out.println("Heap elements:");
        minHeap.printHeap();

        System.out.println("Min element extracted: " + minHeap.extractMin());
        System.out.println("Heap elements after extraction:");
        minHeap.printHeap(); 
	}

}
