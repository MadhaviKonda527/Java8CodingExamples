package com.coderpad;

import java.util.HashMap;
import java.util.Map;

public class FirstNonRepeatingCharacter {

    public static void main(String[] args) {
        // Example input
        String[] inputs = {"array", "apple", "rat"};
        
        // Find and print the first non-repeating character for each string
        for (String input : inputs) {
            char result = findFirstNonRepeatingCharacter(input);
            System.out.print(result + ", ");
        }
    }
    
    public static char findFirstNonRepeatingCharacter(String input) {
        // Create a map to count the frequency of each character
        Map<Character, Integer> frequencyMap = new HashMap<>();
        
        // Populate the frequency map
        for (char c : input.toCharArray()) {
            frequencyMap.put(c, frequencyMap.getOrDefault(c, 0) + 1);
        }
        
        // Find the first character with a frequency of 1
        for (char c : input.toCharArray()) {
            if (frequencyMap.get(c) == 1) {
                return c;
            }
        }
        
        // If no non-repeating character is found, return a placeholder (e.g., a space)
        return ' ';
    }
}

