package com.coderpad;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class LongestOccurenceOfACharacter {

	public static void main(String[] args) {
            String s = "aabbbbcc";
            Map<Character,Integer> map = new TreeMap<>();
            for(char c : s.toCharArray()) {
            	if(map.containsKey(c)) {
            		map.put(c, map.get(c)+1);
            	}
            	else
            		map.put(c, 1);
            }
            System.out.println(map);
	}

}
