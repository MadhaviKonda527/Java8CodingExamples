/*
 * To execute Java, please define "static void main" on a class
 * named Solution.
 *
 * For a given input 2D array of strings, find the maximum average grade, round off to the nearest floor integer.

Input :                 {  {""Rohit"", ""85""},
                                {""Rahul"", ""80""},
                                {""Amit"",""85""},
                                {""Rohit"", ""90""}   }

Output : 87
Logic : Rohit's average grade is (85+90)/2 = 87.5  which when rounded off to floor is  87"*/
package com.coderpad;

import java.util.*;

class MaxAvg {

  public static void main(String[] args){

    String[][] inputData = {{"Rohit","85"},{"Rahul","80"},{"Amit","85"},{"Rohit","90"}};
    Map<String, ArrayList<Integer>> inputMap = new HashMap<>();
    
    for(String[] input : inputData){
      String name = input[0];
      Integer grade = Integer.valueOf(input[1]);
      if(!inputMap.containsKey(name)){
       
      inputMap.put(name,new ArrayList<>(grade));

    }
    else{
      
       inputMap.get(name).add(grade);
      
      
    }

    } 
    int maxAvg =0;
    for(Map.Entry<String,ArrayList<Integer>> entry : inputMap.entrySet()){
      Integer sum=0;
           ArrayList<Integer> grades = entry.getValue();
           for(Integer grade : grades){
            sum = sum+grade;
           }
           if(sum!=0){
           int avg = sum/grades.size();

           if(avg>maxAvg)
           maxAvg= avg;
           }
    }
     System.out.println(maxAvg);
  }
}
