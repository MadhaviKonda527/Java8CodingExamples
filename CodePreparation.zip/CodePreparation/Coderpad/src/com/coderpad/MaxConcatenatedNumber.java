package com.coderpad;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MaxConcatenatedNumber {

    public static void main(String[] args) {
        // Example list of integers
        Integer[] numbers = {3, 7, 4, 90};
        
        // Find and print the maximum concatenated number
        String maxNumber = findMaxConcatenatedNumber(numbers);
        System.out.println("The maximum concatenated number is: " + maxNumber);
    }
    
    public static String findMaxConcatenatedNumber(Integer[] numbers) {
        // Convert each integer to a string
        List<String> stringList = new ArrayList<>();
        for (Integer num : numbers) {
            stringList.add(num.toString());
        }
        
        // Sort the list using a custom comparator
        Collections.sort(stringList, (a, b) -> (b + a).compareTo(a + b));
        
        // Concatenate the sorted strings
        StringBuilder maxNumberBuilder = new StringBuilder();
        for (String str : stringList) {
            maxNumberBuilder.append(str);
        }
        
        // Return the concatenated result
        return maxNumberBuilder.toString();
    }
}
