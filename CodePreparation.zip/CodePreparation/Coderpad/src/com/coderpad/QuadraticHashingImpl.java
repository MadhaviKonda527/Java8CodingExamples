package com.coderpad;

public class QuadraticHashingImpl
{
	//For e.g. Hash(x) be the slot index computed using a hash function and S be the table size
//	If slot hash(x) is full then we try (hash(x)+1*1)%S
//	If slot (hash(x)+1*1)%S) is full the we try (hash(x)+2*2)%S
//	If slot (hash(x)+2*2)%S) is full the we try (hash(x)+3*3)%S
	
	public static void main(String[] args) {
		int arr[]= { 50, 700, 76, 85,92, 73, 101};
		int tableSize=11;
		int hashTable[]=new int[tableSize];
		//initialize hashTable
		for (int i = 0; i < tableSize; i++)
			hashTable[i] = -1;
		
		hashing(hashTable,arr);
	}
 
	private static void hashing(int[] hashTable, int[] arr)
	{
		int tablesize=hashTable.length,n=arr.length;
		//iterating for array arr
		for(int i=0; i<n ; i++)
		{
			//compute the hash value
			int hashvalue=arr[i]%tablesize;
			
			//insert in the table if no collision
			if (hashTable[hashvalue] == -1)
				hashTable[hashvalue] = arr[i];
			else {
				// if collision occurs then use quadratic probing
				int k = 1;
				while (true) {
					int newhashvalue = (hashvalue + k * k) % tablesize;
					if (hashTable[newhashvalue] == -1) {
						hashTable[newhashvalue] = arr[i];
						break;
					}
					k++;
				}
			}
		}
		
		printArray(hashTable);
	}
 
	private static void printArray(int[] hashTable)
	{
		for (int i = 0; i < hashTable.length; i++)
			System.out.println(hashTable[i]);
		// TODO Auto-generated method stub
		
	}
 
}
//{ 50, 700, 76, 85,92, 73, 101}
//73
//-1
//101
//-1
//92
//-1
//50
//700
//85
//-1
//76
