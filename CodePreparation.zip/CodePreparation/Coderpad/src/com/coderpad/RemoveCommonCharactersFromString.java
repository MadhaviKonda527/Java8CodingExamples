package com.coderpad;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveCommonCharactersFromString {

	public static void main(String[] args) {
          String s = "hello world";
          String result = "";
          Set<Character> sset = new LinkedHashSet<>();
          for(int i=0;i<s.length();i++) {
        	  sset.add(s.charAt(i));
          }
          for(char ch : sset) {
        	  result = result + ch;
          }
          System.out.println(result);
          
	}

}
