package com.coderpad;


public class BellmanFordAlgorithm
{
	//class to represent the edge
	class Edge
	{
		int src, dest, weight;
 
		Edge() {
			src = dest = weight = 0;
		}
	};
 
	int V, E;
	Edge edge[];
 
	public BellmanFordAlgorithm(int v, int e)
	{
		V=v;
		E=e;
		edge= new Edge[e];
		for( int i=0; i< e ; ++i)
		{
			edge[i]= new Edge();
		}
	}
 
	//Bellman-Ford algorithm
	void BellmanFord(BellmanFordAlgorithm graph, int src)
	{
		int V= graph.V, E= graph.E;
		//this array will hold the shortest distance from src to i
		int dist[]= new int[V];
 
		//initialize distances from src to all other vertices as infinite
		for(int i=0; i<V; ++i)
		{
			dist[i]=Integer.MAX_VALUE;
		}
		dist[src]=0;
 
		//relax all edges V-1 times
		for(int i=1; i<V; i++)
		{
			for(int j=0;j<E; j++)
			{
				int u=graph.edge[j].src;
				int v=graph.edge[j].dest;
				int weight= graph.edge[j].weight;
				//check if the distance from src to u is not infinite
				//and if the distance from src to u + weight of edge u,v
				//is less than the distance from src to v
				
				if(dist[u]!=Integer.MAX_VALUE &&
						dist[u] + weight < dist[v])
				{
					dist[v] = dist[u] + weight;
				}
			}
		}
		//check for negative weight cycle
		//if we get a shorter path, then there is a cycle
		// as there is no shortest path possible in a graph with negative cycle
		
		for(int j=0; j<E; j++)
		{
			int u=graph.edge[j].src;
			int v=graph.edge[j].dest;
			int weight= graph.edge[j].weight;
			
			//check if the distance from src to u is not infinite
			//and if the distance from src to u + weight of edge u,v	
			//is less than the distance from src to v
			
			if (dist[u] != Integer.MAX_VALUE &&
					dist[u] + weight < dist[v])
			{
				System.out.println("Graph contains negative weight cycle");
				return;
			}
		}
		
		printSolution(dist, V);
	}
 
	 void printSolution(int[] dist, int V)
	 {
		// TODO Auto-generated method stub
		 System.out.println("Vertex \t\t Distance from Source");
		 for(int i=0; i<V; i++)
		 {
			 System.out.println("A-->"+i + "\t : " + dist[i]);
		 }
		 	
	}
	 public static void main(String[] args) {
		 //List of edges-
		 //(A,B), (A,C), (A,D), (B,E), (D,C), (D,F), (C,E), (C,B), (E,F)
		 int V=6;
		 int E=9;
		
		 BellmanFordAlgorithm graph = new BellmanFordAlgorithm(V, E);
		 //(A,B)=6, (A,C)4, (A,D)=5, (B,E)=(-1), (D,C)=(-2), (D,F)=(-1), (C,E)=3, (C,B)=(-2), (E,F)=3
		 //generate edges and weight as above
		 graph.edge[0].src=0;
		 graph.edge[0].dest=1;
		 graph.edge[0].weight=6;
		
		 graph.edge[1].src=0;
		 graph.edge[1].dest=2;
		 graph.edge[1].weight=4;
		
		 graph.edge[2].src=0;
		 graph.edge[2].dest=3;
		 graph.edge[2].weight=5;
		
		 graph.edge[3].src=1;
		 graph.edge[3].dest=4;
		 graph.edge[3].weight=-1;
		
		 graph.edge[4].src=3;
		 graph.edge[4].dest=2;
		 graph.edge[4].weight=-2;
		
		 graph.edge[5].src=3;
		 graph.edge[5].dest=5;
		 graph.edge[5].weight=-1;
		
		 graph.edge[6].src=2;
		 graph.edge[6].dest=4;
		 graph.edge[6].weight=3;
		
		 graph.edge[7].src=2;
		 graph.edge[7].dest=1;
		 graph.edge[7].weight=-2;
		
		 graph.edge[8].src=4;
		 graph.edge[8].dest=5;
		 graph.edge[8].weight=3;
		
		 graph.BellmanFord(graph, 0);
		
		
		
	}
}
 
 
//Bellman-Ford algorithm is used to find the shortest paths from
//the source vertex to all other vertices in the weighted graph.
//It works on the negative edge weights as well.
//It is slower than Dijkstra's algorithm but more versatile,
//as it is capable of handling graphs in which some of the edge
//weights are negative numbers.
//It is used in routing protocols like EIGRP.
//It works on principle of relaxation.
//It is a dynamic programming algorithm.
//Principal of relaxation: If a shortest path from vertex A to vertex B
//is known and an edge from vertex A to vertex C is relaxed,
//then the shortest path from vertex A to vertex C is known.
//Time complexity of Bellman-Ford algorithm is O(VE),
//where V is the number of vertices
 
//Step 1: Initialize the distance value initially as infinite to
//all the vertices except the source vertex.
//Initialize the distance value to the source vertex as 0.
//Step 2: Relax all the edges V-1 times.
// V means the number of vertices in the graph.
//Step 3: Visit each edge and relax the path if the previous
// was not accurate. To relax the path, for the vertices and for edge
//u and v,
//if dist[u]+weight(u,v)<dist[v],
//then update dist[v]=dist[u]+weight(u,v).
//means if sum of distance of source to u and weight of edge u,v
//is less than the distance of source to v, then update the distance of v.
//Step 4: Check if the new distance value is less than the previous distance value
//if yes, then update the distance value  in each iteration for the
// edges.
// the distance value to every vertex is the total  distance from
// the source vertex to that particular vertex.