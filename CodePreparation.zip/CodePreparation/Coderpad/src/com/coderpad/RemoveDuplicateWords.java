package com.coderpad;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicateWords {

    public static void main(String[] args) {
        // Example inputs
        String input1 = "Good day day bye bye";
        String input2 = "greet the day user greet good day";
        
        // Process and print the outputs
        System.out.println(removeDuplicates(input1));
        System.out.println(removeDuplicates(input2));
    }
    
    public static String removeDuplicates(String sentence) {
        // Split the sentence into words
        String[] words = sentence.split("\\s+");
        
        // Use LinkedHashSet to maintain insertion order and remove duplicates
        Set<String> uniqueWords = new LinkedHashSet<>();
        
        // Add words to the set
        for (String word : words) {
            uniqueWords.add(word);
        }
        
        // Join the unique words into a single string with spaces
        return String.join(" ", uniqueWords);
    }
}
