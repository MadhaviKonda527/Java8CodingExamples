package com.coderpad;

public class StringWeightCalculator {

    public static void main(String[] args) {
        // Example input
        String input = "Apple";
        
        // Calculate and print the weight of the string
        int weight = calculateWeight(input);
        System.out.println("Weight of the given string: " + weight);
    }
    
    public static int calculateWeight(String input) {
        int totalWeight = 0;
        
        // Convert the input string to lowercase to handle case insensitivity
        input = input.toLowerCase();
        
        // Iterate through each character in the string
        for (char c : input.toCharArray()) {
            // Check if the character is a letter
            if (Character.isLetter(c)) {
                // Calculate the position in the alphabet (a = 1, b = 2, ..., z = 26)
                int position = c - 'a' + 1;
                // Add the position value to the total weight
                totalWeight += position;
            }
        }
        
        return totalWeight;
    }
}

