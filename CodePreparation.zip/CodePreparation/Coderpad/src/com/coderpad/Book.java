package com.coderpad;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Book {
	
	User user = new User();
	
	String bookRequest = user.getRequestBook();
	
	Map<String, Integer> bookMap = new HashMap<>();
	public void borrowCopy(User user){
		//bookMap.entrySet().stream().filter(entry -> entry.equals(bookRequest)).collect(Collectors.toList());
	    for(Map.Entry<String, Integer> entry : bookMap.entrySet()) {
	    	if(entry.getKey().equals(bookRequest))
	    		if(entry.getValue()>0)
	    			user.Books.add(entry.getKey());
	    			user.userBooks.put(user.getUserName(), user.Books);
	    }
	}
	
	public void returnCopy(User user) {
		
		
	}
}
