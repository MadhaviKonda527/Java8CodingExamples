package com.coderpad;

public class DoubleHashing {

    public static void main(String[] args) {
        int[] arr = {20, 35, 76, 81, 90};
        int n = arr.length;
        int[] hashtable = new int[n];
        
        
        for (int i = 0; i < hashtable.length; i++) {
            hashtable[i] = -1;
        }

        
        for (int i = 0; i < n; i++) {
            int key = arr[i];
            insert(hashtable, key, n);
        }

        
        printArray(hashtable);
    }

    private static void insert(int[] hashtable, int key, int tableSize) {
        int hash1 = key % tableSize; // Primary hash function
        int hash2 = 1 + (key % (tableSize - 1)); // Secondary hash function
        
        int index = hash1;

        
        while (hashtable[index] != -1) {
            index = (index + hash2) % tableSize;
        }

        hashtable[index] = key;
    }

    private static void printArray(int[] hashTable) {
        for (int i = 0; i < hashTable.length; i++) {
            System.out.println(hashTable[i]);
        }
    }
}
