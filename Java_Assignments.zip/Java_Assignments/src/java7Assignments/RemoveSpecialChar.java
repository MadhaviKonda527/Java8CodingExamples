package java7Assignments;

public class RemoveSpecialChar {
	public static void main(String[] args) {
		String s = "1@huhjn#";
		String s1=removeSpecialChar(s);
		System.out.println(s1);

	}

	private static String removeSpecialChar(String s) {
		StringBuilder sb=new StringBuilder();
       for(char ch :s.toCharArray()) {
    	   if(Character.isAlphabetic(ch) || Character.isDigit(ch)) {
    		   sb.append(ch);
    	   }
       }
       return sb.toString();
	}

}
