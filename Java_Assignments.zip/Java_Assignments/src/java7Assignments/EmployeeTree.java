package java7Assignments;

import java.util.Comparator;

public class EmployeeTree implements Comparable<EmployeeTree>{
	
	private int empid;
	private String name;
	private double salary;
	
	public EmployeeTree(int id, String name, double sal) {
		this.empid = id;
		this.name = name;
		this.salary = sal;
	}
	
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	@Override
	public int compareTo(EmployeeTree emp) {
		return  Integer.compare(this.empid, emp.empid);
	}
	
	public static Comparator<EmployeeTree> NameComparator = new Comparator<EmployeeTree>() {
		@Override
		public int compare(EmployeeTree e1, EmployeeTree e2) {
			return e1.name.compareTo(e2.name);
		}
	};


	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary=" + salary + "]";
	}
	

}
