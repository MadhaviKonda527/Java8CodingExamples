package java7Assignments;

class MyClass implements MyFunctionalInterface{
	
	@Override
	public void abstractMethod() {
		System.out.println("abstract method in myclass");
	}
	
	

}


