package java7Assignments;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class RemoveDuplicatesFromList {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
        list.add(2);
        list.add(3);
        list.add(3);
        list.add(3);
        list.add(65);
        list.add(4);
        list.add(3);
        list.add(3);
        list.add(2);
        System.out.println("Original list: " + list);
        HashSet<Integer> set = new HashSet<>(list);
        List<Integer> newList = new ArrayList<>(set);
        System.out.println("List with duplicates removed: " + newList);
	}

}
