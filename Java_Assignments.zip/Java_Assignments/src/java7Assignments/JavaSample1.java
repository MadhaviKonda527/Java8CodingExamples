package java7Assignments;
import java.util.Collections.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map;

public class JavaSample1 {

	public static void main(String[] args) {
        Map<Integer,String> str= new HashMap<>();
        str.put(1, "Aadi");
        str.put(2, "Manoj");
        str.put(3, "vikas");
        System.out.println(str);
	}
	
		
	

}
