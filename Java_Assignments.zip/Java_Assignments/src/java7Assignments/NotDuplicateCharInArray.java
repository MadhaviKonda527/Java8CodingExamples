package java7Assignments;

import java.util.HashMap;
import java.util.Map;

public class NotDuplicateCharInArray {

	public static void main(String[] args) {
		char[] charArray = {'a', 'b', 'a', 'c'};
        Map<Character, Integer> charCountMap = new HashMap<>();
        for (char c : charArray) {
            charCountMap.put(c, charCountMap.getOrDefault(c, 0) + 1);
        }
        char nonDuplicateChar = '\0'; 
        for (char c : charArray) {
            if (charCountMap.get(c) == 1) {
                nonDuplicateChar = c;
                break;
            }
        }
        System.out.println("Non-duplicate character: " + nonDuplicateChar);
	}

}
