package java7Assignments;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SortTheIntegers {

	public static void main(String[] args) {
      //int a[] = new int[] {2,4,0,1,56,23,4};
      List <Integer> arr = Arrays.asList(2,4,0,1,56,23,4);
      
      System.out.println("Sorted array");
      Object[] array = arr.toArray();
      Arrays.sort(array);
      System.out.println(Arrays.toString(array));
      
	}

}
