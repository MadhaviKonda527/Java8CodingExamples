package java7Assignments;

import java.util.Arrays;

public class SortAlphabetically {

	public static void main(String[] args) {
       String s[] = new String[] {"Capgemini","Accenture","TCS","EPAM"};
       Arrays.sort(s);
       System.out.println("Sorted strings are:"+Arrays.toString(s));
       
       
	}

}
