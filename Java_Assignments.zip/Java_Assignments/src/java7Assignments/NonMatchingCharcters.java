package java7Assignments;

public class NonMatchingCharcters {
	public static void main(String[] args) {
		String s="madhuadh";
		findNonMatchChar(s);
		
	}
 public static void findNonMatchChar(String s) {
	 System.out.println("Non match charcters");
	 int[] charCount=new int[256];
	 for(char ch:s.toCharArray()) {
		 charCount[ch]++;
	 }
	 for(char ch :s.toCharArray()) {
		 if(charCount[ch]==1) {
			 System.out.println(ch+" ");
		 }
	 }
 }

}
