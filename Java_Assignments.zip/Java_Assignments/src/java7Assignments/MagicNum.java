package java7Assignments;

public class MagicNum {

	public static void main(String[] args) {
         int n = 19, sum =0;
         while(n>0) {
        	 sum = sum+ n%10;
        	 n = n/10;
        	 if(sum<9) {
        		 break;
        	 }
         }
         if(sum==1)
        	 System.out.println("Its a magic Num");
         else
        	 System.out.println("Its not a magic Num");
         
	}

}
