package java7Assignments;

@FunctionalInterface
interface MyFunctionalInterface {
	
	void abstractMethod();
	default void defaultMethod() {
		System.out.println("default method");
	}

}
