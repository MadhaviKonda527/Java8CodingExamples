package java7Assignments;

public class FibonacciExample {

	public static void main(String[] args) {
		int maxNumber = 30; 
        int first = 0, second = 1;
        System.out.println("Fibonacci series up to " + maxNumber + ":");
        System.out.print(first + " "); 
        while (second <= maxNumber) {
            System.out.print(second + " ");
            int next = first + second;
            first = second;
            second = next;
        }
	}

}
