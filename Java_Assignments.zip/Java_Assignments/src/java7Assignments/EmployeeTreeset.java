package java7Assignments;

class EmployeeTreeset implements Comparable<EmployeeTreeset>{
          
	   private int id;
	   private String name;
	   
	   
	public EmployeeTreeset(int id, String name) {
	    this.id = id;
		this.name = name;
	}
	@Override
	public int compareTo(EmployeeTreeset other) {
		return Integer.compare(this.id,  other.id);
	}
	@Override
	public String toString() {
		return "EmployeeTreeset [id=" + id + ", name=" + name + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	   
	

}
