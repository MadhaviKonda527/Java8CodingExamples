package java7Assignments;

import java.util.Scanner;

public class CountTheOccurenceOfALetter {
    public static void main(String[] args) {
    	/*char[] s = {'h','e','l','l','o'};
    	int count =0;
    	Scanner sc = new Scanner(System.in);
    	char find = sc.next().charAt(0);
    	for(char str:s){
    		if(find == str) 
    			count++;
    		
    			
    	}
    	System.out.println("Count:"+count);*/
    	String s = "Hello";
    	int count=0;
    	Scanner sc = new Scanner(System.in);
    	char find = sc.next().charAt(0);
    	for(int i=0;i<s.length();i++) {
    		if(find==s.charAt(i)) {
    			count++;
    		}
    	}
    	System.out.println("Count:"+count);
    }
}
