package java7Assignments;

import java.util.Comparator;

public class Employee implements Comparable<Employee>{
	
	private int empid;
	private String name;
	private double salary;
	
	public Employee(int id, String name, double sal) {
		this.empid = id;
		this.name = name;
		this.salary = sal;
	}
	
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	@Override
	public int compareTo(Employee emp) {
		return  Integer.compare(this.empid, emp.empid);
	}
	
	public static Comparator<Employee> NameComparator = new Comparator<Employee>() {
		@Override
		public int compare(Employee e1, Employee e2) {
			return e1.name.compareTo(e2.name);
		}
	};


	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary=" + salary + "]";
	}
	

}
