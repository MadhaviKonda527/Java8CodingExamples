package java7Assignments;
import java.util.Scanner;

public class FibonacciSeries {

	public static void main(String[] args) {
          Scanner sc = new Scanner(System.in);
          System.out.println("enter a value:");
          int n = sc.nextInt();
          int n1 = 0, n2 = 1, i=0;
          while(i<n)
          {
        	  System.out.println(n1);
        	  int n3 = n1+n2;
        	  n1=n2;
        	  n2=n3;
        	  i++;
          }
	}

}
