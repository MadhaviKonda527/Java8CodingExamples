package java7Assignments;

import java.util.Arrays;
import java.util.stream.Collectors;

public class JavaSample2 {

	public static void main(String[] args) {
		//String [] a = {"Jeff", "Bill", "Mark","Markus","Daniel"};
		//Arrays.asList(a).stream().filter(s -> s.length()>5).forEach(System.out::println);
	  String s = "abcdefabcdeabcdaaa";
	   
	  //String newString =	originalString.chars().filter(c->c!=charToRemove).mapToObj(c->(char)c).map(String::valueOf).collect(Collectors.joining());
	  
	  String collect = s.chars().filter(c -> c!='a').mapToObj(c -> (char)c).map(String::valueOf).collect(Collectors.joining());
	  System.out.println(collect);
	}
	

}
