package java7Assignments;

public class CountTheWords {

	public static void main(String[] args) {
         String s = "Hello World java";
         int count =0;
         String []str = s.split("[ \\n\\t]+");
         for( String sa:str) {
        	 count++;
         }
         System.out.println("Count of words in string:"+count+"words");
	}

}
