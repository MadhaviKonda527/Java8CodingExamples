package java7Assignments;

public class MissingNum {

	public static void main(String[] args) {
        int a[] = {1,2,3,6,7};
        int max = a[a.length-1];
        
        System.out.println("Missisng numbers in array:");
        for(int i =0;i<max;i++) {
        	int count=0;
        	for(int arr : a) {
        		if(arr == i) {
        			count++;
        		break;
        	}}
        	if(count==0)
        		System.out.println(i);
        }
	}

}
