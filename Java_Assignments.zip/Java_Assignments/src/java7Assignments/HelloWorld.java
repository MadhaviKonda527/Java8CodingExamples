package java7Assignments;

public class HelloWorld {

	public static void main(String[] args) {
      String s = "Hello World";
      for(int i=1;i<=10;i++) {
    	  System.out.println(s+" "+i);
      }
	}

}
