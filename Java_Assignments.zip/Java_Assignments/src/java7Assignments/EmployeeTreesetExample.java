package java7Assignments;

import java.util.TreeSet;

public class EmployeeTreesetExample {

	public static void main(String[] args) {
           TreeSet<EmployeeTreeset> treeSet = new TreeSet<>();
           EmployeeTreeset emp1 = new EmployeeTreeset(1,"Anil");
           EmployeeTreeset emp2 = new EmployeeTreeset(2,"Vikas");
           
           treeSet.add(emp1);
           treeSet.add(emp2);
           
           System.out.println("Employees:");
           for(EmployeeTreeset emp : treeSet) {
        	   System.out.println(emp);
           }
	}

}
