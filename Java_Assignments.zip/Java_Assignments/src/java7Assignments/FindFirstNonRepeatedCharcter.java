package java7Assignments;

public class FindFirstNonRepeatedCharcter {
	public static void main(String[] args) {
		 String s="Madhavi";
		 char ch=findNonRepeatedChar(s);
		 System.out.println(ch);
	}
	 public static char findNonRepeatedChar(String word) {
		  int[] charCount = new int[256];
		  System.out.println(charCount[0]);
		  for (char ch : word.toCharArray()) {//97
			  charCount[ch]++; charCount[97]=2;
		  }
		  
		  for (char ch : word.toCharArray()) {
		    if (charCount[ch] == 1) {
		      return ch;
		    }
		  }
		  return '\0'; 
		}

}
