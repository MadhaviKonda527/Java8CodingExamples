package java7Assignments;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmployeeExample {

	public static void main(String[] args) {
          List<Employee> employees = new ArrayList<>();
          employees.add(new Employee(1,"Anil", 20000));
          employees.add(new Employee(3,"Mahi", 80000));
          employees.add(new Employee(2,"Venkat", 49000));
          
          Collections.sort(employees);
          System.out.println("Sorting on empid");
          for(Employee emp : employees) {
        	  System.out.println(emp);
          }
          
          Collections.sort(employees, Employee.NameComparator);
          System.out.println("Sorting on empname");
          for(Employee emp : employees) {
        	  System.out.println(emp);
          }
          
	}

}
