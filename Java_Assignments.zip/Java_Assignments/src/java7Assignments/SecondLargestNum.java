package java7Assignments;

import java.util.Arrays;

public class SecondLargestNum {

	public static void main(String[] args) {
         int a[] = new int[] {2,3,5,6,1,0};
         Arrays.sort(a);
         System.out.println("2nd largest num:"+a[a.length-2]);
	}

}
