package java7Assignments;

import java.util.Arrays;

public class MissingNumberInArray {
	public static void main(String[] args) {
		int[] num= new int[100];
		for(int i=1;i<=100;i++) {
			if(i==67) {
				continue;
			}
		   num[i-1]=i;
		}
		int[] missingNum = findMissingNumbers(num);
		System.out.println(Arrays.toString(missingNum));
	}
	 
	 public static int[] findMissingNumbers(int[] arr) {
		  int expectedSum = 100 * (100 + 1) / 2;
		  int actualSum = 0;
		  for (int num : arr) {
		    actualSum += num;
		  }

		  int missingSum = expectedSum - actualSum;
		  
		  if (missingSum == 100 * 101 / 2) {
		    return new int[0]; 
		  }
		  
		  return new int[]{missingSum};
		}

}
