package java7Assignments;

import java.util.Arrays;

public class StringAnagram {
	public static void main(String[] args) {
		String s1 = "venky";
		String s2 = "venky";
		boolean b = checkAnagramOrNot(s1, s2);
		if (b)
			System.out.println("Two strings are anagrams");
		else
			System.out.println("Two strings not anagrams");
	}

	public static boolean checkAnagramOrNot(String s1, String s2) {
		if (s1.length() != s2.length()) {
			return false;
		}

		char[] ch1 = s1.toCharArray();
		Arrays.sort(ch1);
		char[] ch2 = s2.toCharArray();
		Arrays.sort(ch2);
		return Arrays.equals(ch1, ch2);
	}

}
