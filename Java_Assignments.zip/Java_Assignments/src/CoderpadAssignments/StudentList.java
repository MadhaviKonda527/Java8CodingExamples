package CoderpadAssignments;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class StudentList {

	public static void main(String[] args) {
         List<Student> sl = new ArrayList<>();
         
         sl.add(new Student(111,"naveen","IT"));
         sl.add(new Student(112,"praveen","Mechanical"));
         sl.add(new Student(112,"Ashok","civil"));
         
         ListIterator itr = sl.listIterator();
         
         while(itr.hasNext()) {
        	 System.out.println(itr.next());
         }
         
         sl.get(1);
         sl.remove(2);
         sl.remove(sl.get(0));
         
	}
	
	
	

}
