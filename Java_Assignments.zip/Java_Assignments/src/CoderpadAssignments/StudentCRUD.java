package CoderpadAssignments;

import java.util.ArrayList;

public class StudentCRUD {
	
	public static void insertStudent(int sId, String sName, String department) {
		
		StringBuilder sb = new StringBuilder();
		sb.append("insert into Student(sId, sname, department) values(111, 'naveen','IT')");
		
	}
	
	public static Student getStudent() {
		Student s = new Student();
	    Student s1 = null;
		StringBuilder sb = new StringBuilder();
		sb.append("select from Student where sId = '"+s.getsId()+"'");
		return s1;
	}
	
	public static Student getAllStudent() {
		
	    Student sAll = null;
		StringBuilder sb = new StringBuilder();
		sb.append("select * from Student");
		return sAll;
	}

}
