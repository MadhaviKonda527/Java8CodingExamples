package CoderpadAssignments;

public class Student {

	private int sId;
	
	private String sName;
	
	private String department;

	public int getsId() {
		return sId;
	}

	public void setsId(int sId) {
		this.sId = sId;
	}

	public String getsName() {
		return sName;
	}

	public void setsName(String sName) {
		this.sName = sName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public  Student(int sId, String sname, String department) {
		this.sId = sId;
		this.sName = sName;
		this.department = department;
		
	}

}
