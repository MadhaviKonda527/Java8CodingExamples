package com.dp;

public class BuilderDp {

	private int id;

	private String name;

	private long phoneNumber;

	public BuilderDp(BuilderClass builderClass) {
		this.id = builderClass.id;
		this.name = builderClass.name;
		this.phoneNumber = builderClass.phoneNumber;
	}

	public BuilderDp() {
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	@Override
	public String toString() {
		return "BuilderDp [id=" + id + ", name=" + name + ", phoneNumber=" + phoneNumber + "]";
	}

	static class BuilderClass {

		private int id;

		private String name;

		private long phoneNumber;

		public BuilderClass setId(int id) {
			this.id = id;
			return this;
		}

		public BuilderClass setName(String name) {
			this.name = name;
			return this;
		}

		public BuilderClass setPhoneNumber(long phoneNumber) {
			this.phoneNumber = phoneNumber;
			return this;
		}

		public BuilderDp build() {
			return new BuilderDp(this);
		}

	}

}
