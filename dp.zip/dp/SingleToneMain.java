package com.dp;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;

public class SingleToneMain {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, InstantiationException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException, FileNotFoundException,
			IOException, ClassNotFoundException, CloneNotSupportedException {

//		SingleToneDp sp=SingleToneDp.getObj();
//		System.out.println(sp.hashCode());
//		SingleToneDp sp1=SingleToneDp.getObj();
//		System.out.println(sp1.hashCode());
		
//		for (int i = 0; i < 10; i++) {
//			SingleToneDp sp = SingleToneDp.getObj();
//			System.out.println(sp.hashCode());
//		}
//
		SingleToneDp sp = SingleToneDp.getObj();
//		System.out.println(sp.hashCode());

		//1.  reflection api
//		solution by  throwing exception in private constructor
//		Constructor<SingleToneDp> constructor = SingleToneDp.class.getDeclaredConstructor();
//		constructor.setAccessible(true);
//		SingleToneDp newConstructor = constructor.newInstance();
		
//		for (int i = 0; i < 10; i++) {
//			Constructor<SingleToneDp> constructor = SingleToneDp.class.getDeclaredConstructor();
//			constructor.setAccessible(true);
//			SingleToneDp newConstructor = constructor.newInstance();
//			SingleToneDp newConstructor1 = constructor.newInstance();
//			SingleToneDp newConstructor2 = constructor.newInstance();
			
//		}
//
//		System.out.println(newConstructor.hashCode());

//		2. Deserialization method
//		solution : Implementing readResolve() 

		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("ab.ob"));
		oos.writeObject(sp);
		
		
//
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("ab.ob"));
		SingleToneDp s1 = (SingleToneDp) ois.readObject();
		SingleToneDp s2 = (SingleToneDp) ois.readObject();
		SingleToneDp s3 = (SingleToneDp) ois.readObject();
		System.out.println(s1.hashCode() +" - "+s2.hashCode());
		
		
		//3. cloning method
//		solution  override clone() and return sp
//		SingleToneDp cloneSp= (SingleToneDp)sp.clone();
//		System.out.println(cloneSp.hashCode());
	}

}
