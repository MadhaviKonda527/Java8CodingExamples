package com.dp.Prototype;

import java.util.UUID;

public class Main {

	public static void main(String[] args) throws CloneNotSupportedException {
		Network n = new Network();
		n.setSomeData(UUID.randomUUID());
		n.setIp("127.0.0.1");
		n.setDomain(new Domain("www", "120.4.3"));
		System.out.println(n);

		Network n1 = (Network) n.clone();
		n1.getDomain().setDns("127.0.0.1");
		n1.setSomeData(UUID.randomUUID());
		n1.setDomain(new Domain("www","190,45,3434"));
		System.out.println(n1);
		
		Network n2 = (Network) n.clone();
		System.out.println(n2);
		

	}

}
