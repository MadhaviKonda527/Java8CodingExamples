package com.dp.Prototype;

import java.util.UUID;

public class Network implements Cloneable {

	private String ip;

	private UUID someData;

	private Domain domain;

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public UUID getSomeData() {
		return someData;
	}

	public void setSomeData(UUID someData) {
		this.someData = someData;
	}

	public Domain getDomain() {
		return domain;
	}

	public void setDomain(Domain domain) {
		this.domain = domain;
	}

	@Override
	public String toString() {
		return "Network [ip=" + ip + ", someData=" + someData + ", domain=" + domain + "]";
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		Network n = new Network();
		n.setIp(this.getIp());
		n.setSomeData(this.someData);
		n.setDomain(new Domain(this.domain.getSubDomain(), this.domain.getDns()));
		return n;
	}

}
