package com.dp.Prototype;

public class Domain {

	private String subDomain;

	private String dns;

	public String getSubDomain() {
		return subDomain;
	}

	public void setSubDomain(String subDomain) {
		this.subDomain = subDomain;
	}

	public String getDns() {
		return dns;
	}

	public void setDns(String dns) {
		this.dns = dns;
	}

	@Override
	public String toString() {
		return "Domain [subDomain=" + subDomain + ", dns=" + dns + "]";
	}

	public Domain(String subDomain, String dns) {
		super();
		this.subDomain = subDomain;
		this.dns = dns;
	}

	public Domain() {
		super();
	}

}
