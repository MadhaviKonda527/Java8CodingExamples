package com.dp;

import java.lang.reflect.Constructor;

public class BuilderDpMain {

	public static void main(String[] args) throws ReflectiveOperationException, SecurityException {

		BuilderDp bp = new BuilderDp.BuilderClass().setId(23).setName("Devraj").setPhoneNumber(9900123123L).build();
//		Constructor<SingleToneDp> constructor = SingleToneDp.class.getDeclaredConstructor();
//		constructor.setAccessible(true);
//		SingleToneDp newInstance = constructor.newInstance();

//		System.out.println(newInstance.hashCode());
		System.out.println(bp);

	}

}
