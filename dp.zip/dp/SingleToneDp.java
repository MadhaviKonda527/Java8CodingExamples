package com.dp;

import java.io.Serializable;

public class SingleToneDp implements Serializable, Cloneable {

	private SingleToneDp() {
		if (sp != null) {
			throw new RuntimeException("Singletone Design Pattern Can't be Break");
		}
	}

////	eager Dp
//	private static SingleToneDp sp = new SingleToneDp();
//
//	public static SingleToneDp getObj() {
//		return sp;
//	}

	// lazy ininialization
//	private static SingleToneDp sp;
//
//	public static SingleToneDp getObj() {
//		if (sp == null) {
//			sp=new SingleToneDp();
//		}
//		return sp;
//	}

	// method syncronized

//	private static SingleToneDp sp;
//
//	public synchronized static SingleToneDp getObj() {
//		if (sp == null) {
//			new SingleToneDp();
//		}
//		return sp;
//	}

	// Syncronized block of code
	private static SingleToneDp sp=null;

	public static SingleToneDp getObj() {
		if (sp == null) {
//			100 lines of code 
			synchronized (SingleToneDp.class) {
				if (sp == null) {
					sp = new SingleToneDp();
				}
			}

		}
		return sp;
	}

	// used in object cloning
//	@Override
//	protected Object clone() throws CloneNotSupportedException {
//		return sp;  // u can use super.clone() to clone  
//	}

	// used in deserialization
	public Object readResolve() {
		return sp;
		
	}

//	@Override
//	public Object clone() throws CloneNotSupportedException {
//		return super.clone();
//	}

}
