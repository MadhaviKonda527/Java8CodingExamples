package com.java7.programs;

public class MissingNumberInASeries {

		    public static int findMissingNumber(int[] nums) {
		        int n = nums.length + 1; // Because one number is missing
		        int expectedSum = (n * (n + 1)) / 2;
		        int actualSum = 0;
		        for (int num : nums) {
		            actualSum += num;
		        }
		        return expectedSum - actualSum;
		    }

		    public static void main(String[] args) {
		        int[] testCase1 = {1, 2, 3, 4, 5, 7, 8, 9, 10}; // Test case a
		        int missingNumber1 = findMissingNumber(testCase1);
		        System.out.println("Missing number in test case 1: " + missingNumber1);

		        // Adjust test cases for proper range
		        int[] testCase2 = {2, 4, 6, 10, 12, 14, 16, 18, 20}; // Test case b
		        int missingNumber2 = findMissingNumberInArithmeticSequence(testCase2, 2, 2);
		        System.out.println("Missing number in test case 2: " + missingNumber2);

		        int[] testCase3 = {1, 3, 5, 9, 11, 13, 15, 17}; // Test case c
		        int missingNumber3 = findMissingNumberInArithmeticSequence(testCase3, 1, 2);
		        System.out.println("Missing number in test case 3: " + missingNumber3);
		    }

		    // Finds missing number in a list where the numbers are in an arithmetic sequence
		    public static int findMissingNumberInArithmeticSequence(int[] nums, int first, int diff) {
		        int n = nums.length + 1;
		        int expectedSum = (n * (2 * first + (n - 1) * diff)) / 2;
		        int actualSum = 0;
		        for (int num : nums) {
		            actualSum += num;
		        }
		        return expectedSum - actualSum;
		    
	}

}
