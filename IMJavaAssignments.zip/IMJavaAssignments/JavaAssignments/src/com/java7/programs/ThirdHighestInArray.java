package com.java7.programs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class ThirdHighestInArray {

	public static void main(String[] args) {
		
		        // Example array
		        int[] array = {12, 35, 1, 10, 34, 1, 35, 50};

		        // Find and print the third highest element
		        try {
		            int result = findThirdHighest(array);
		            System.out.println("The third highest element is: " + result);
		        } catch (Exception e) {
		            System.out.println(e.getMessage());
		        }
		    }

		    public static int findThirdHighest(int[] array) throws Exception {
		        if (array.length < 3) {
		            throw new Exception("Array must contain at least 3 elements.");
		        }

		        // Use a Set to remove duplicates
		        Set<Integer> uniqueElements = new TreeSet<>(Collections.reverseOrder());
		        for (int num : array) {
		            uniqueElements.add(num);
		        }

		        // Check if there are at least 3 unique elements
		        if (uniqueElements.size() < 3) {
		            throw new Exception("Array must contain at least 3 distinct elements.");
		        }

		        // Convert the Set to a List
		        List<Integer> sortedList = new ArrayList<>(uniqueElements);

		        // Return the third highest element
		        return sortedList.get(2);
		    

	}

}
