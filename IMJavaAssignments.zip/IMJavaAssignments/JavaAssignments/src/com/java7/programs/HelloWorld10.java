package com.java7.programs;

public class HelloWorld10 {

	public static void main(String[] args) {
           String s = "HelloWorld";
           for(int i=0;i<=10;i++) {
        	   System.out.println(s+" "+i);
           }
	}

}
