package com.employee.example;

public class Employee implements Comparable<Employee> {
	 long eid;
	 String ename; 
	 float esalary; 
	 Address address;
	
	public Employee(long eid, String ename, float esalary, Address address) {
		this.eid = eid;
		this.ename = ename;
		this.esalary = esalary;
		this.address = address;
		
	}
	
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", esalary=" + esalary + ", address=" + address + "]";
	}

	public long getEid() {
		return eid;
	}
	public void setEid(long eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public float getEsalary() {
		return esalary;
	}
	public void setEsalary(float esalary) {
		this.esalary = esalary;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	public void increaseSalary(int percentage) {
		this.esalary = this.esalary * 1.10f ;
		//this.setEsalary(this.getEsalary() + this.getEsalary()*(percentage/100));
		
	}
	
	public boolean isPrime(long eid) {
		int count =0;
		for(int i=1;i<=eid;i++) {
			if(eid%i==0) {
				count ++;
			}
		}
		if(count<3)
		return true;
		else 
			return false;
	}

	@Override
	public int compareTo(Employee o) {
		return Long.compare(this.eid, o.eid);
	}
	

}
