package com.employee.example;

public class Address {
	
	private String Dno;
	private String city;
	private String State;
	private double pincode;
	
	public Address(String Dno, String city, String State, double pincode) {
		this.Dno = Dno;
		this.city = city;
		this.State = State;
		this.pincode = pincode;
	}
	
	public String getDno() {
		return Dno;
	}
	public void setDno(String dno) {
		Dno = dno;
	}

	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public double getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [Dno=" + Dno + ", city=" + city + ", State=" + State + ", pincode=" + pincode + "]";
	}

	

}
