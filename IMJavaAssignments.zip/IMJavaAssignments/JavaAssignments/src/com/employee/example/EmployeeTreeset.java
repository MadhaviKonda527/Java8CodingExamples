package com.employee.example;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EmployeeTreeset {

	public static void main(String[] args) {
          Set<Employee> empSet = new TreeSet<Employee>();
          empSet.add(new Employee(111,"Sravan",7000,new Address("H-25","Hyderabad","Telangana",500072)));
          empSet.add(new Employee(112,"Pavan",45000,new Address("H-23","Cyberabad","Telangana",500072)));
          empSet.add(new Employee(113,"Anand",7000,new Address("H-24","Secunderabad","Telangana",500072)));
          empSet.add(new Employee(114,"Sriha",36000,new Address("H-26","Ahmedabad","Maharastra",133242)));
          empSet.add(new Employee(115,"Aadya",9000,new Address("H-27","Aurangabad","Maharastra",500082)));
          empSet.add(new Employee(116,"Aaradhya",5000,new Address("H-28","Banglore","Karnataka",500032)));
          empSet.add(new Employee(117,"Anvi",8000,new Address("H-30","Banglore","Karnataka",500032)));
          empSet.add(new Employee(118,"Aloka",2000,new Address("H-31","Kolkata","WestBengal",503462)));
          empSet.add(new Employee(119,"Meghana",19000,new Address("H-32","Mumbai","Maharastra",500082)));
          empSet.add(new Employee(120,"Vishist",11000,new Address("H-33","Banglore","Karnataka",500032)));
          
          
          
          
			//1
			  //empSet.stream() .filter(e -> e.getEsalary() < 10000) .forEach(e ->
			  //e.setEsalary(e.getEsalary() * 1.10f)); empSet.forEach(System.out::println);
			  
			  //2
			  //List<Employee> collect = empSet.stream().filter(e -> e.getAddress().getCity().endsWith("re")).collect(Collectors.toList());
			
          //collect.forEach(System.out::println);
          
          //3
          //empSet.stream().filter(e -> e.isPrime(e.getEid())).forEach(System.out::println);
          
          //4
          //empSet.stream().collect(Collectors.groupingBy(e -> e.getAdress().getPincode())).forEach(pincode, empList);
          //Map<Double, List<Employee>> groupedByPincode = empSet.stream()
                  //.collect(Collectors.groupingBy(e -> e.getAddress().getPincode()));
          /*Map<Double, TreeSet<Employee>> groupedByPincode = new TreeMap<>();

          for (Employee emp : empSet) {
              double pincode = emp.getAddress().getPincode();
              groupedByPincode
                  .computeIfAbsent(pincode, k -> new TreeSet<>())
                  .add(emp);
          }

          // Print grouped employees
          groupedByPincode.forEach((pincode, employeeSet) -> {
              System.out.println("Pincode: " + pincode);
              empSet.forEach(System.out::println);
              System.out.println();
          });*/
          List<Employee> collect = empSet.stream().collect(Collectors.toList());
          Map<Double, List<Employee>> groupedByPincode = collect.stream()
                  .collect(Collectors.groupingBy(e -> e.getAddress().getPincode()));

          // Print grouped employees
          groupedByPincode.forEach((pincode, empList) -> {
              System.out.println("Pincode: " + pincode);
              empList.forEach(System.out::println);
              System.out.println();
          });
          

			  //empSet.stream().filter(e -> e.getEsalary()<10000).forEach(e ->
			  //e.increaseSalary(10)); empSet.forEach(System.out::println);
			 
	}

}
	