package com.interviewtrackingsystem.techpanelservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechpanelserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
