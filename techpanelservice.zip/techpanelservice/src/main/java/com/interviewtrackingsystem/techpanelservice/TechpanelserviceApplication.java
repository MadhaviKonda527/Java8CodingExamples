package com.interviewtrackingsystem.techpanelservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechpanelserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechpanelserviceApplication.class, args);
	}

}
