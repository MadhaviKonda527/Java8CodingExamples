package com.interviewtrackingsystem.hrpanelservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrpanelserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
