package java8Programs;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

public class CountOfEachNumber {

	public static void main(String[] args) {

		List<Integer> intarr = Arrays.asList(2,3,34,5,5,4,3,3,3);
		intarr.stream().collect(Collectors.
	}

}
