package java8Programs;

import java.util.Arrays;
import java.util.List;

public class FindStringsLengthGreaterFive {
	public static void main(String[] args) {
        List<String> strings = Arrays.asList("apple", "banana", "cherry", "date", "fig", "grapefruit");

        long count = strings.stream()
                            .filter(s -> s.length() > 5) 
                            .count(); 

        System.out.println("Number of strings with length greater than 5: " + count);
    }
}
