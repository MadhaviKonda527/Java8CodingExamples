package java8Programs;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SortTheIntegers {
	public static void main(String[] args) {
        List<Integer> list = Arrays.asList(5, 3, 8, 1, 2);

        List<Integer> sortedList = list.stream()
                                        .sorted() // Sort the elements in natural order
                                        .collect(Collectors.toList()); // Collect the sorted elements into a new list

        System.out.println("Sorted list: " + sortedList);
    }
}
