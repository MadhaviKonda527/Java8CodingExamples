package java8Programs;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class NumbersStartsWitOne {
	public static void main(String[] args) {
        List<Integer> list = Arrays.asList(1, 200, 11, 100);

        List<Integer> numbersStartingWithOne = list.stream()
            .filter(n -> String.valueOf(n).startsWith("1"))
            .collect(Collectors.toList());

        System.out.println(numbersStartingWithOne);
    }
}
