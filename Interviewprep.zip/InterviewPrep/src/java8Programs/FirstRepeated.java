package java8Programs;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class FirstRepeated {
	public static void main(String[] args) {
        String input = "AABCDDE"; 

        Optional<Character> firstNonRepeated = input.chars() 
            .mapToObj(c -> (char) c) 
            .collect(Collectors.groupingBy(c -> c, LinkedHashMap::new, Collectors.counting())) 
            .entrySet().stream() 
            .filter(entry -> entry.getValue() == 2) 
            .map(Map.Entry::getKey) 
            .findFirst(); 

        firstNonRepeated.ifPresent(character -> System.out.println("First non-repeated character: " + character));
    }
}
