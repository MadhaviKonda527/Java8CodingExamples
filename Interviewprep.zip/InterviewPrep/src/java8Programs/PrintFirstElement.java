package java8Programs;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class PrintFirstElement {
	public static void main(String[] args) {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);

        Optional<Integer> firstElement = list.stream()
                                             .findFirst(); // Get the first element

        firstElement.ifPresent(System.out::println); // Print if present
    }
}
