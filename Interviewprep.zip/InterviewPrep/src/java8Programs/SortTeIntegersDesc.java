package java8Programs;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortTeIntegersDesc {
	public static void main(String[] args) {
        List<Integer> list = Arrays.asList(5, 3, 8, 1, 2);

        List<Integer> sortedList = list.stream()
                                        .sorted((a, b) -> b.compareTo(a)) // Sort in descending order
                                        .collect(Collectors.toList()); // Collect the sorted elements into a new list

        System.out.println("Sorted list in descending order: " + sortedList);
        List<Integer> sortList = list.stream()
                .sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        System.out.println("Sorted list in descending order: " + sortedList);

    }
}
