package java8Programs;

import java.util.StringJoiner;

public class StringJoinerExample {
	public static void main(String[] args) {
        StringJoiner joiner = new StringJoiner(", ", "[", "]"); // Create a StringJoiner with delimiter, prefix, and suffix

        // Adding strings to the StringJoiner
        joiner.add("Apple");
        joiner.add("Banana");
        joiner.add("Cherry");

        // Joining the strings
        String result = joiner.toString(); // Convert to String

        System.out.println("Joined String: " + result); // Output: [Apple, Banana, Cherry]
    }
}
