import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public class FirstRepeatedCharacter {
    public static void main(String[] args) {
        String input = "AABCDDE"; // Example input

        Optional<Object> firstRepeated = input.chars() // Convert the string to a stream of characters
            .mapToObj(c -> (char) c) // Convert int stream to Character stream
            .collect(LinkedHashMap::new, 
                     (map, character) -> {
                         map.put(character, map.getOrDefault(character, 0) + 1); // Count occurrences
                     }, 
                     LinkedHashMap::putAll) // Merge maps
            .entrySet().stream() // Create a stream of the entries
            .filter(entry -> entry.getValue() > 1) // Filter for repeated characters
            .map(Map.Entry::getKey) // Extract the character
            .findFirst(); // Get the first repeated character

        firstRepeated.ifPresent(character -> System.out.println("First repeated character: " + character));
    }
}
