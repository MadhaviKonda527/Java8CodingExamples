package java8Programs;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class MaxElement {
	public static void main(String[] args) {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);

        Optional<Integer> maxValue = list.stream()
                                          .max(Comparator.naturalOrder()); // Find the maximum value

        maxValue.ifPresent(value -> System.out.println("Maximum value: " + value));
    }
}
