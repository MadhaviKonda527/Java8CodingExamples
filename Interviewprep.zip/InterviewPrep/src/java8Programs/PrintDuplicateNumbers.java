package java8Programs;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class PrintDuplicateNumbers {
	public static void main(String[] args) {
        List<Integer> list = Arrays.asList(1, 2, 3, 3, 2, 0);

        List<Integer> duplicates = list.stream()
            .collect(Collectors.groupingBy(n -> n, Collectors.counting())) // Group by each number and count occurrences
            .entrySet().stream()
            .filter(entry -> entry.getValue() > 1) // Filter entries with count greater than 1
            .map(Map.Entry::getKey) // Extract the duplicate numbers
            .collect(Collectors.toList());

        System.out.println(duplicates);
    }
}
