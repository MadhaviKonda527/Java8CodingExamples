package interview;

import java.util.LinkedList;

public class BigBasketPlmStatement {

	private static final int BulkBuyLimit = 10;
	private static final int BulkBuyLimitCategory = 5;
	private static final String Category = "Paracetmol";
	
	

	public static void main(String[] args) {
            LinkedList<OrderedItemdetails>  items = new LinkedList<>();
            items.add(new OrderedItemdetails(1, "Paracetmol", 3));
            items.add(new OrderedItemdetails(2, "Analgesic", 11));
            items.add(new OrderedItemdetails(3, "Choclate", 8));
            items.add(new OrderedItemdetails(4, "Paracetmol", 2));
            
            int totalParacetmolQuantity =0;
            for(OrderedItemdetails item : items) {
            	if(item.quantity>BulkBuyLimit) {
            		System.out.println( "Breached");
            		break;
            	}
            	if(item.category.equals(Category)) {
            		totalParacetmolQuantity = totalParacetmolQuantity + item.quantity;
            		if(totalParacetmolQuantity>BulkBuyLimitCategory) {
            			System.out.println( "Breached");
            		}
            		else if(item.productId == items.size())
            			System.out.println( "Met");
            			
            	}
            }
            } }
