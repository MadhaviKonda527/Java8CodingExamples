package interview;

public class OrderedItemdetails {
          int productId;
          String category;
          int quantity;
      
   

public OrderedItemdetails(int productId, String category, int quantity) {
	   this.productId = productId;
	   this.category = category;
	   this.quantity = quantity;
   }
   
}
