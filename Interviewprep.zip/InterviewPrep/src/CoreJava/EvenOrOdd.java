package CoreJava;

public class EvenOrOdd {
	public static void main(String[] args) {
	       int n = 35;
	       if(n%2==0) 
	    	   System.out.println(n+" is Even number");
	       else
	    	   System.out.println(n+" is Odd number"); 
	       
		}
}
