package CoreJava;

public class RemoveCharFromString {

	public static void main(String[] args) {
            String s = "aahuniisjade";
            s = s.replaceAll("a", "");
            System.out.println(s);
	}

}
