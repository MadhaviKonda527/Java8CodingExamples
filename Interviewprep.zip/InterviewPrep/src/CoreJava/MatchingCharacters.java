package CoreJava;

public class MatchingCharacters {
	public static void main(String[] args) {
		String s="madhavi";
		findDuplicates(s);
	}

		public static void findDuplicates(String s) {
			System.out.println("Find duplicates");
			int[] charCount=new int[256];
			for(char ch:s.toCharArray()) {
				charCount[ch]++;
			}
			
			for(char ch: s.toCharArray()) {
				if(charCount[ch]>1) {
					System.out.println(ch+" ");
				}
			}
		  }

}
