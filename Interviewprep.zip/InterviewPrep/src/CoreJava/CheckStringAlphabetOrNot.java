package CoreJava;

public class CheckStringAlphabetOrNot {
	public static void main(String[] args) {
		String s="venky";
		boolean b=checkAlphabets(s);
		System.out.println(b);
	}

	private static boolean checkAlphabets(String s) {
		for (char ch: s.toCharArray()) {
			if(!Character.isLetter(ch)) {
				return false;
			}
		}
		return true;
		
	}
}
