package CoreJava;
import java.util.Scanner;

public class CountTheOccurenceOfALetter {
	public static void main(String[] args) {
    	String s = "Hello";
    	int count=0;
    	Scanner sc = new Scanner(System.in);
    	char find = sc.next().charAt(0);
    	for(int i=0;i<s.length();i++) {
    		if(find==s.charAt(i)) {
    			count++;
    		}
    	}
    	System.out.println("Count:"+count);
    }

}
