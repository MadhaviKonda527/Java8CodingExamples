package CoreJava;

import java.util.LinkedList;
import java.util.Iterator;

public class DeleteElementFromLinkedList {
    public static void main(String[] args) {
        LinkedList<String> list = new LinkedList<>();
        list.add("apple");
        list.add("banana");
        list.add("cherry");
        list.add("date");

        String elementToRemove = "banana";
        removeElement(list, elementToRemove);

        System.out.println(list);  
    }

    public static void removeElement(LinkedList<String> list, String element) {
        Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()) {
            String current = iterator.next();
            if (current.equals(element)) {
                iterator.remove();  
                break;  
            }
        }
    }
}
