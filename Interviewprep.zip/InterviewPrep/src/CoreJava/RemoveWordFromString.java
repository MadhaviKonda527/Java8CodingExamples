package CoreJava;

public class RemoveWordFromString {

	public static void main(String[] args) {
           String s = "Java Programming Exercise";
           String w = "Java";
           s = s.replaceAll(w, "");
           System.out.println(s);
	}

}
