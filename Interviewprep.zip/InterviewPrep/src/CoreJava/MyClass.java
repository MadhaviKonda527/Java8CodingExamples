package CoreJava;

public class MyClass implements MyFunctionalInterface{
	
	@Override
	public void abstractMethod() {
		System.out.println("abstract method in myclass");
	}
    
	@Override
	public void defaultMethod() {
		MyFunctionalInterface.super.defaultMethod();
		System.out.println("default method in myclass");
	}
   public static void main(String args[]) {
	   MyClass m = new MyClass();
	   m.defaultMethod();
   }
}
