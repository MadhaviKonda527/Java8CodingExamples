package CoreJava;

public class wiceTheCharactersInString {

	public static void main(String[] args) {
             String s = "welcome";
             String s2 = "";
             int l = s.length()-1;
             int s2Length = l+l;
             for(int i =0;i<=l;i++) {
            	 s2 = s2 + s.charAt(i)+s.charAt(i);
             }
             System.out.println(s2);
	}

}
