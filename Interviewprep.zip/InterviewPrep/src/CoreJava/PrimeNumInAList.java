package CoreJava;
import java.util.Arrays;
import java.util.List;

public class PrimeNumInAList {
	public static void main(String[] args) {
        List<Integer> a = Arrays.asList(3,8,67,10,35,67);
        
        for(int an : a) {
       	 int count = 0;
            for(int i=1;i<=an;i++) {
           	if(an%i ==0)
           		count++;
            }
            if(count==2)
           	 System.out.println(an+" Prime");
            else
           	 System.out.println(an+" Not Prime");
        }
	}

}
