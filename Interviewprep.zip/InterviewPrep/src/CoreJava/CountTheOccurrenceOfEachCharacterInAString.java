package CoreJava;
import java.util.HashMap;
import java.util.Map;

public class CountTheOccurrenceOfEachCharacterInAString {
	public static void main(String[] args) {
        String s= "HelloWorld";
        Map <Character, Integer> countChar = new HashMap<>();
        for(int i=0;i<s.length()-1;i++) {
     	   if(countChar.containsKey(s.charAt(i))) {
     		   int count = countChar.get(s.charAt(i));
     		   countChar.put(s.charAt(i), ++count);
     	   }
     	   else {
     		   countChar.put(s.charAt(i), 1);
     	   }
        }
        System.out.println(countChar);
        for(Character key : countChar.keySet()) {
     	   if(countChar.get(key)>1)
     		   System.out.println(key+" "+countChar.get(key));
        }
        
	}
}
