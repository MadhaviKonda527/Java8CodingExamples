package CoreJava;

public class MultipleCatchBlocks {
	public static void main(String[] args) {
        try {
            int[] numbers = {1, 2, 3};
            int index = 4; 
            int result = numbers[index]; 
            int divisionResult = 10 / result;
            System.out.println("Result of division: " + divisionResult);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index out of bounds!");
        } catch (ArithmeticException e) {
            System.out.println("Arithmetic exception occurred: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Some other exception occurred: " + e.getMessage());
        }
    }
}
