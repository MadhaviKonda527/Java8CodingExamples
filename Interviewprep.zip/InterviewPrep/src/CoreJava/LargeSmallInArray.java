package CoreJava;

public class LargeSmallInArray {
	public static void main(String[] args) {
		int[] array = {3, 9, 1, 7, 4, 2, 8, 5, 6};
		 
        
        int minElement = array[0];
        int maxElement = array[0];
 
        
        for (int i = 1; i < array.length; i++) {
            if (array[i] < minElement) {
                minElement = array[i];
            }
            if (array[i] > maxElement) {
                maxElement = array[i];
            }
        }
        System.out.println("Smallest element: " + minElement);
        System.out.println("Largest element: " + maxElement);
	}
}
