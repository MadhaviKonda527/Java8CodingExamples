package CoreJava;

public class Mythread extends Thread{

	@Override
   public void run() {
	   System.out.println("run");
   }
	
	public static void main(String args[]) {
		Mythread mt = new Mythread();
		mt.start();
	}

}
