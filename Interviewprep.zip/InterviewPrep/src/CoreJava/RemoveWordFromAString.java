package CoreJava;

public class RemoveWordFromAString {

	public static void main(String[] args) {
           String s = "Java Programming Exercise";
           String w = "Java";
           String [] sarr = s.split(" ");
           for(int i=0;i<sarr.length;i++) {
        	   if(sarr[i].equals(w)) {
        		   sarr[i]="";
        	   }
        	   
           }
           for(int i=0;i<sarr.length;i++) {
           System.out.println(sarr[i]);
           }
           s ="";
           for(int i=0;i<sarr.length;i++) {
        	   s = s + sarr[i]+" ";
           }
           System.out.println(s);
	}

}
