package CoreJava;

@FunctionalInterface
public interface MyFunctionalInterface {
	void abstractMethod();
	default void defaultMethod() {
		System.out.println("default method");
	}
}
