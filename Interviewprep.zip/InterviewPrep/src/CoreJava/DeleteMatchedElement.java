package CoreJava;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Iterator;


public class DeleteMatchedElement {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LinkedList<Integer> list = new LinkedList<>();


        System.out.println("Enter the number of elements you want to add to the LinkedList:");
        int n = scanner.nextInt();
        System.out.println("Enter " + n + " integers:");
        for (int i = 0; i < n; i++) {
            list.add(scanner.nextInt());
        }

        System.out.print("Enter the element to delete: ");
        int elementToDelete = scanner.nextInt();

        
        Iterator<Integer> iterator = list.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().equals(elementToDelete)) {
                iterator.remove();
            }
        }

        
        System.out.println("Updated LinkedList: " + list);

        scanner.close();
    }
}
