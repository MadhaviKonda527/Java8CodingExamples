package CoreJava;
public class Product implements Comparable<Product> {

	@Override
	public int compareTo(Product other) {
		return this.productName.compareTo(other.productName);
	}
	private int productId;
	private String productName;
	
	public Product(int productId, String productName) {
		this.productId = productId;
		this.productName = productName;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + "]";
	}
	}
