package CoreJava;
import java.util.Arrays;
import java.util.Comparator;

public class SortStringsAscDescOnItsLength {
	

	
	    public static void main(String[] args) {
	        String[] strings = {"apple", "banana", "kiwi", "cherry", "strawberry", "fig"};

	        
	        String[] ascendingOrder = strings.clone();
	        Arrays.sort(ascendingOrder, Comparator.comparingInt(String::length));
	        System.out.println("Sorted in Ascending Order by Length: " + Arrays.toString(ascendingOrder));

	        
	        String[] descendingOrder = strings.clone();
	        Arrays.sort(descendingOrder, Comparator.comparingInt(String::length).reversed());
	        System.out.println("Sorted in Descending Order by Length: " + Arrays.toString(descendingOrder));
	    }
	}


