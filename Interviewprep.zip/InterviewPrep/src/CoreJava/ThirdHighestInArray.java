package CoreJava;
import java.util.Scanner;

public class ThirdHighestInArray {
	public static void main(String[] args) {
		int temp;
	      Scanner sc = new Scanner(System.in);
	      System.out.println("enter n value:");
	      int n = sc.nextInt();
	      int []a = new int[n];
	      System.out.println("enter array elements:");
	      for(int i=0;i<=n-1;i++) {
	    	  a[i]=sc.nextInt();
	      }
	      int first = a[0];
	      for(int i=1;i<a.length-1;i++) {
	    	  if(a[i]>first)
	    		  first = a[i];
	      
	      }
	      int second = Integer.MIN_VALUE;
	      for(int i=0;i<a.length-1;i++) {
	    	  if(a[i]>second&& a[i]<first)
	    		  second = a[i];
	      }
	      //System.out.println("third largest number:"+a[3]);
	      int third = Integer.MIN_VALUE;
	      for(int i=0;i<a.length-1;i++) {
	    	  if(a[i]>third&&a[i]<second)
	    		  third = a[i];
	      }
	      System.out.println("third largest number:"+third);
		}
}
