package CoreJava;
import java.util.HashMap;
import java.util.Map;


public class CountTheVowelsInAString {
	public static void main(String[] args) {
        String s = "Hello World";
        //char []a = new char[] {'a','e','i','o','u'};
        Map<Character, Integer> vowelMap = new HashMap<>();
        Map<Character, Integer> vowelCount = new HashMap<>();
        vowelMap.put('a', 0);
        vowelMap.put('e', 0);
        vowelMap.put('i', 0);
        vowelMap.put('o', 0);
        vowelMap.put('u', 0);
        s = s.toLowerCase();
        for(int i=0;i<=s.length()-1;i++) {
       	 char ch = s.charAt(i);
       	 if(vowelMap.containsKey(ch)) {
       		 if(vowelCount.containsKey(ch)) {
       			 int count = vowelCount.get(ch);
       			 vowelCount.put(ch, ++count);
       		 }
       		 else {
       			 vowelCount.put(ch, 1);
       		 }
       	 }
        }
        System.out.println(vowelCount);
        
        
        
        
        
       	 
	}

}
