package CoreJava;

public class RemoveSpecialCharacters {
    public static void main(String[] args) {
        String originalString = "hello@world!123";
        String cleanedString = removeSpecialCharacters(originalString);
        System.out.println(cleanedString);  
    }

    public static String removeSpecialCharacters(String input) {
        return input.replaceAll("[^a-z]", "");
    }
}
