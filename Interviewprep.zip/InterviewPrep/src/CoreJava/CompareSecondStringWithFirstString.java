package CoreJava;

public class CompareSecondStringWithFirstString {

	public static void main(String[] args) {
           String s1 = "Java";
           String s2 = "Ja";
           if(s1.contains(s2))
        	   System.out.println("True");
           else
        	   System.out.println("False");
	}

}
