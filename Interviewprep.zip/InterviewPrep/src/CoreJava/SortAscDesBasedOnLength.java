package CoreJava;

public class SortAscDesBasedOnLength {

	public static void main(String[] args) {
             String[] s = {"Green", "White", "Black", "Pink", "Orange", "Blue", "Champagne", "Indigo", "Ivory" };
             int l = s.length-1;
             System.out.println("Ascending Order");
             for(int i=0;i<=l;i++) {
            	 if(i!=l) {
            	 if(s[i].length()>s[i+1].length()) {
            		 String temp = s[i];
            		 s[i] = s[i+1];
            		 s[i+1] = temp;
            	 }
            	 }
            		 
             }
             for(int i=0;i<=l;i++) {
            	 System.out.println(s[i]);
             }
             System.out.println("Descending Order");
             for(int i=0;i<=l;i++) {
            	 if(i!=l) {
            	 if(s[i].length()<s[i+1].length()) {
            		 String temp = s[i];
            		 s[i] = s[i+1];
            		 s[i+1] = temp;
            	 }
            	 }
             }
             for(int i=0;i<=l;i++) {
            	 System.out.println(s[i]);
             }
             
	} }
