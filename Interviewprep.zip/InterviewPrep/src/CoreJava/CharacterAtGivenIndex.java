package CoreJava;

public class CharacterAtGivenIndex {
    public static void main(String []args) {
    	String a = "Madhavi";
    	int index  = 5;
    	if(index<a.length()) {
    		System.out.println(a.charAt(index));
    		System.out.println((int)a.charAt(index));
    		
    		
    	}
    	else {
    		System.out.println("given index is larger than string's length");
    	}
    	
    }
}
