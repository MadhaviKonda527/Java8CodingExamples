package CoreJava;

public class ReverseWordsInString {

	public static void main(String[] args) {

		String s = "Java Programming";
	     String[] sarr = s.split(" ");
	     for(int i = sarr.length-1; i>=0;i--) {
	    	 System.out.print(sarr[i]+" ");
	     }
	}

}
